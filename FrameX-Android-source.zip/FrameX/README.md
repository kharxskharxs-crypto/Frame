# FRAME X — Android FPS & Performance Analyzer

Kotlin · Jetpack Compose · Material 3 · Room · Android SDK (minSdk 26, targetSdk 34)

## Build APK
**Android Studio:** Open โฟลเดอร์นี้ → รอ Gradle Sync → Build > Build APK(s)
**CLI:** `gradle :app:assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34) → `app/build/outputs/apk/debug/app-debug.apk`
**GitHub Actions:** push ขึ้น GitHub → workflow `Build APK` จะสร้าง artifact `FrameX-APK` ให้อัตโนมัติ

## ให้ได้ Game FPS จริง (สำคัญ)
Android ไม่เปิดให้แอปทั่วไปอ่านเฟรมของเกมอื่น แอปจึงอ่านจาก `dumpsys SurfaceFlinger --latency`
ต้องทำอย่างใดอย่างหนึ่ง:
1. `adb shell pm grant com.framex.android android.permission.DUMP` (ครั้งเดียว ไม่ต้อง Root)
2. เครื่อง Root (แอปเรียก `su` เอง)
แล้วเปิด Overlay + Usage Access ในแท็บ Setup และกด "ทดสอบแหล่งข้อมูล FPS"
ถ้าอ่านไม่ได้ Game FPS แสดง N/A (ไม่มีการสร้างตัวเลขปลอม)

## ค่าที่อ่านไม่ได้จะเป็น N/A
CPU/GPU usage และอุณหภูมิ CPU ขึ้นกับ SELinux/รอมของแต่ละเครื่อง (/proc/stat, /sys/class/kgsl ฯลฯ)
ดูว่าเครื่องคุณอ่านอะไรได้ที่ Setup > ตรวจสอบ

## โครงสร้าง
- core/Sources.kt — Shell, SurfaceFlinger frame source, foreground app tracker
- core/Engine.kt — วัด FPS/1%/0.1% low, ตรวจ stutter/FPS drop, บันทึกเซสชัน
- core/SystemReader.kt — CPU/GPU/RAM/Temp/Battery/Refresh Rate
- core/Analyzer.kt — Smart Analyzer (rule-based จากข้อมูลจริง)
- core/Bench.kt — CPU + Render benchmark
- core/Exporter.kt — CSV / PDF
- service/MonitorService.kt — Foreground service + Floating Overlay
- ui/* — Compose UI (Monitor / Analyze / Bench / History / Setup)
