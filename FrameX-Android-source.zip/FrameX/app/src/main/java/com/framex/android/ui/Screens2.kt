package com.framex.android.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.framex.android.core.*
import com.framex.android.data.*
import com.framex.android.service.MonitorService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private fun fmtDate(ms: Long) = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(ms))

// ───────────────────────── Benchmark ─────────────────────────
@Composable
fun BenchScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by Db.dao.benches().collectAsState(initial = emptyList())
    var phase by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("BEFORE") }
    var selected by remember { mutableStateOf(listOf<Long>()) }
    var viewRef by remember { mutableStateOf<BenchView?>(null) }

    if (phase == "render") {
        Dialog(onDismissRequest = {}, properties = DialogProperties(
            dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize().background(Bg)) {
                AndroidView(factory = { c -> BenchView(c).also { viewRef = it } }, modifier = Modifier.fillMaxSize())
                Text(status, color = Cyan, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp))
            }
        }
    }

    fun run() = scope.launch {
        val sys = SystemReader(ctx)
        val hz = sys.refreshRate()
        val tStart = sys.snapshot().let { it.tempCpu ?: it.tempBat }
        phase = "cpu"
        status = "ทดสอบ CPU แบบ single-thread…"
        val single = CpuBench.run(3f, 1)
        status = "ทดสอบ CPU แบบ multi-thread…"
        val multi = CpuBench.run(3f, Runtime.getRuntime().availableProcessors())
        phase = "render"
        while (viewRef == null) delay(50)
        val v = viewRef!!
        delay(500)
        val stages = ArrayList<Triple<Int, Float, Float>>()
        for ((i, n) in BenchView.STAGES.withIndex()) {
            status = "ทดสอบกราฟิก ${i + 1}/${BenchView.STAGES.size} — $n วัตถุ"
            v.objects = n; delay(1000)
            v.beginRecord(); delay(4000)
            val t = v.endRecord()
            val avg = FrameMath.avgFps(t) ?: 0f
            stages.add(Triple(n, avg, FrameMath.low1(t) ?: avg))
        }
        phase = ""; viewRef = null
        val tEnd = sys.snapshot().let { it.tempCpu ?: it.tempBat }
        val stability = stages.map { if (it.second > 0) it.third / it.second else 0f }.average().toFloat().coerceIn(0.2f, 1f)
        val render = (stages.sumOf { (it.second * it.first / 400.0) } * stability).roundToInt()
        val cpu = (single + multi * 0.2).roundToInt()
        val total = (cpu * 0.4 + render * 0.6).roundToInt()
        val allAvg = stages.map { it.second }.average().toFloat()
        Db.dao.insertBench(BenchEntity(
            timeMs = System.currentTimeMillis(), label = label,
            cpuSingle = single.toFloat(), cpuMulti = multi.toFloat(),
            cpuScore = cpu, renderScore = render, total = total,
            stages = stages.joinToString(";") { "${it.first}:${"%.1f".format(it.second)}:${"%.1f".format(it.third)}" },
            avgFps = allAvg, low1 = stages.map { it.third }.average().toFloat(), refreshHz = hz,
            tempStart = tStart, tempEnd = tEnd,
            device = "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"))
        status = ""
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("BENCHMARK", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        NeonCard {
            Text("ทดสอบ CPU (single/multi) + กราฟิก 5 ระดับ ใช้เวลา ~35 วินาที", color = TextMain, fontSize = 13.sp)
            Text("คะแนนเป็นค่าสัมพัทธ์ ใช้เทียบ \"ก่อน/หลังปรับแต่ง\" บนเครื่องเดียวกันเท่านั้น และจำกัดโดย Refresh Rate ของจอ",
                color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("BEFORE", "AFTER", "—").forEach {
                    FilterChip(selected = label == it, onClick = { label = it }, label = { Text(it) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { run() }, enabled = phase == "", modifier = Modifier.fillMaxWidth()) {
                Text(if (phase == "") "เริ่ม BENCHMARK" else status)
            }
        }

        if (selected.size == 2) {
            val a = list.firstOrNull { it.id == selected[0] }
            val b = list.firstOrNull { it.id == selected[1] }
            if (a != null && b != null) {
                val (o, n) = if (a.timeMs <= b.timeMs) a to b else b to a
                fun d(x: Number, y: Number): String {
                    val xv = x.toDouble(); val yv = y.toDouble()
                    return if (xv == 0.0) "N/A" else "%+.1f%%".format((yv - xv) / xv * 100)
                }
                NeonCard {
                    SectionTitle("เปรียบเทียบ  ${o.label} (${fmtDate(o.timeMs)})  →  ${n.label} (${fmtDate(n.timeMs)})")
                    Spacer(Modifier.height(6.dp))
                    listOf(
                        "Performance Score" to "${o.total} → ${n.total}  ${d(o.total, n.total)}",
                        "CPU Score" to "${o.cpuScore} → ${n.cpuScore}  ${d(o.cpuScore, n.cpuScore)}",
                        "Render Score" to "${o.renderScore} → ${n.renderScore}  ${d(o.renderScore, n.renderScore)}",
                        "Avg FPS" to "${f1(o.avgFps)} → ${f1(n.avgFps)}  ${d(o.avgFps, n.avgFps)}",
                        "1% Low" to "${f1(o.low1)} → ${f1(n.low1)}",
                        "อุณหภูมิหลังจบ" to "${f1(o.tempEnd)} → ${f1(n.tempEnd)} °C"
                    ).forEach { (k, v) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            Text(k, color = Dim, modifier = Modifier.weight(1f), fontSize = 13.sp)
                            Text(v, color = TextMain, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else if (list.size >= 2) Text("แตะ 2 รายการเพื่อเปรียบเทียบ", color = Dim, fontSize = 12.sp)

        list.forEach { b ->
            val sel = b.id in selected
            NeonCard(Modifier.clickable {
                selected = if (sel) selected - b.id else (selected + b.id).takeLast(2)
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${b.total}", color = if (sel) Green else Cyan, fontSize = 28.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                        Text("${b.label} · ${fmtDate(b.timeMs)} · ${b.device}", color = Dim, fontSize = 11.sp)
                    }
                    TextButton(onClick = { scope.launch { Db.dao.deleteBench(b.id); selected = selected - b.id } }) { Text("ลบ", color = Red) }
                }
                Text("CPU ${b.cpuScore} (1T ${b.cpuSingle.roundToInt()}/s · MT ${b.cpuMulti.roundToInt()}/s) · Render ${b.renderScore} · Avg ${f1(b.avgFps)} FPS · จอ ${b.refreshHz.roundToInt()}Hz",
                    color = TextMain, fontSize = 12.sp)
                Text("Stages: " + b.stages.split(";").joinToString("  ") { s -> val p = s.split(":"); "${p[0]}→${p[1].toFloat().roundToInt()}fps" },
                    color = Dim, fontSize = 11.sp)
            }
        }
    }
}

// ───────────────────────── History ─────────────────────────
@Composable
fun HistoryScreen() {
    val list by Db.dao.sessions().collectAsState(initial = emptyList())
    var open by remember { mutableStateOf<SessionEntity?>(null) }
    open?.let { s -> SessionDetail(s, onBack = { open = null }); return }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("HISTORY", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        if (list.isEmpty()) NeonCard { Text("ยังไม่มีประวัติ — เซสชันจะถูกบันทึกอัตโนมัติเมื่อวัดเกมได้ ≥ 5 วินาที", color = Dim) }
        list.forEach { s ->
            NeonCard(Modifier.clickable { open = s }) {
                Text(s.appName, fontWeight = FontWeight.Bold)
                Text("${fmtDate(s.startMs)} · ${s.durationMs / 60000}m${(s.durationMs / 1000) % 60}s", color = Dim, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text("AVG ${f1(s.avgFps)} · 1%L ${f1(s.low1)} · Stutter ${s.stutters} · Drop ${s.drops}",
                    color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SessionDetail(s: SessionEntity, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var samples by remember { mutableStateOf<List<SampleEntity>>(emptyList()) }
    var events by remember { mutableStateOf<List<EventEntity>>(emptyList()) }
    LaunchedEffect(s.id) { samples = Db.dao.samples(s.id); events = Db.dao.events(s.id) }
    val findings = remember(samples, events) { if (samples.isEmpty()) emptyList() else Analyzer.analyze(s, samples, events) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ กลับ") }
            Text(s.appName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Text("${fmtDate(s.startMs)} · ${s.durationMs / 1000}s · จอ ${s.refreshHz.roundToInt()}Hz · ${s.source}", color = Dim, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("AVG", f1(s.avgFps), Modifier.weight(1f)); Tile("MIN", f1(s.minFps), Modifier.weight(1f)); Tile("MAX", f1(s.maxFps), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("1% LOW", f1(s.low1), Modifier.weight(1f)); Tile("0.1% LOW", f1(s.low01), Modifier.weight(1f))
            Tile("AVG FT", s.avgFrameMs?.let { "%.1fms".format(it) } ?: "N/A", Modifier.weight(1f))
        }
        NeonCard {
            Text("Game FPS", color = Dim, fontSize = 12.sp)
            LineChart(samples.map { it.fps ?: 0f }, minY = 0f, maxY = s.refreshHz, height = 110.dp)
        }
        NeonCard {
            Text("Frame time สูงสุดต่อวินาที (ms)", color = Dim, fontSize = 12.sp)
            LineChart(samples.map { it.maxMs ?: 0f }, color = Red, minY = 0f, guides = listOf(16.7f, 33.3f), height = 110.dp)
        }
        if (samples.any { it.cpu != null || it.gpu != null }) NeonCard {
            Text("CPU % (ฟ้า) / GPU % (น้ำเงิน)", color = Dim, fontSize = 12.sp)
            LineChart(samples.map { it.cpu ?: 0f }, minY = 0f, maxY = 100f, height = 90.dp)
            LineChart(samples.map { it.gpu ?: 0f }, color = Blue, minY = 0f, maxY = 100f, height = 90.dp)
        }
        NeonCard {
            Text("อุณหภูมิ (°C)", color = Dim, fontSize = 12.sp)
            LineChart(samples.map { it.tempCpu ?: it.tempBat ?: 0f }, color = Amber, height = 90.dp)
        }
        NeonCard {
            Text("ช่วงที่เกมกระตุก / FPS ตก (${events.size})", color = Dim, fontSize = 12.sp)
            events.take(40).forEach {
                val t = it.tMs / 1000
                Text("%02d:%02d  %s  %.1f".format(t / 60, t % 60, it.type, it.value), color = if (it.type == "DROP") Amber else Red, fontSize = 12.sp)
            }
        }
        SectionTitle("SMART ANALYZER")
        FindingsList(findings)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { scope.launch { val f = withContext(Dispatchers.IO) { Exporter.csv(ctx, s, samples) }; Exporter.share(ctx, f, "text/csv") } }, Modifier.weight(1f)) { Text("CSV") }
            Button(onClick = { scope.launch { val f = withContext(Dispatchers.IO) { Exporter.pdf(ctx, s, samples, findings) }; Exporter.share(ctx, f, "application/pdf") } }, Modifier.weight(1f)) { Text("PDF") }
            OutlinedButton(onClick = { scope.launch { Db.dao.deleteSession(s.id); onBack() } }, Modifier.weight(1f)) { Text("ลบ", color = Red) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ───────────────────────── Setup ─────────────────────────
@Composable
private fun PermRow(title: String, desc: String, ok: Boolean, action: String, onAction: () -> Unit) {
    NeonCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text((if (ok) "✅ " else "⚠️ ") + title, fontWeight = FontWeight.Bold)
                Text(desc, color = Dim, fontSize = 12.sp)
            }
            if (!ok) Button(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
private fun PrefSwitch(label: String, get: () -> Boolean, set: (Boolean) -> Unit, ctx: android.content.Context) {
    var v by remember { mutableStateOf(get()) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; set(it); MonitorService.refresh(ctx) })
    }
}

@Composable
fun SetupScreen() {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act.lifecycle.addObserver(o); onDispose { act.lifecycle.removeObserver(o) }
    }
    var diag by remember { mutableStateOf("") }
    var probe by remember { mutableStateOf<List<Pair<String, Boolean>>>(emptyList()) }
    var op by remember { mutableFloatStateOf(Prefs.opacity) }
    var ts by remember { mutableFloatStateOf(Prefs.textSize) }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val usageOk = remember(tick) { ForegroundTracker.hasAccess(ctx) }
    val cmd = "adb shell pm grant ${ctx.packageName} android.permission.DUMP"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("SETUP", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        SectionTitle("PERMISSIONS")
        PermRow("Display over other apps", "จำเป็นสำหรับ Floating Overlay", overlayOk, "เปิด") {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }
        PermRow("Usage Access", "ใช้ตรวจว่าเกมไหนอยู่ด้านหน้า (โหมดอัตโนมัติ)", usageOk, "เปิด") {
            ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        NeonCard {
            Text("แหล่ง Game FPS: DUMP / Root", fontWeight = FontWeight.Bold)
            Text("Android ไม่ให้แอปทั่วไปอ่านเฟรมของแอปอื่น วิธีที่ใช้ได้จริงคือให้สิทธิ์ DUMP ครั้งเดียวผ่านคอมพิวเตอร์ (ไม่ต้อง Root) หรือใช้เครื่อง Root:",
                color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            SelectionContainer { Text(cmd, color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)) }
            Button(onClick = {
                scope.launch {
                    diag = "กำลังทดสอบ…"
                    diag = withContext(Dispatchers.IO) {
                        when (Shell.resolve(true)) {
                            Shell.Mode.DIRECT -> "✅ อ่าน SurfaceFlinger ได้ (สิทธิ์ DUMP) — Game FPS ใช้งานได้"
                            Shell.Mode.ROOT -> "✅ อ่าน SurfaceFlinger ได้ (Root) — Game FPS ใช้งานได้"
                            else -> "❌ อ่านไม่ได้ — Game FPS จะแสดง N/A (บางรอมอาจบล็อกแม้ให้สิทธิ์แล้ว)"
                        }
                    }
                }
            }) { Text("ทดสอบแหล่งข้อมูล FPS") }
            if (diag.isNotEmpty()) Text(diag, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp)
        }
        NeonCard {
            Text("เซนเซอร์ที่เครื่องนี้อ่านได้", fontWeight = FontWeight.Bold)
            Button(onClick = { scope.launch { probe = withContext(Dispatchers.IO) { SystemReader(ctx).probe() } } },
                modifier = Modifier.padding(vertical = 6.dp)) { Text("ตรวจสอบ") }
            probe.forEach { (n, ok) -> Text((if (ok) "✅ " else "❌ N/A  ") + n, fontSize = 13.sp, color = if (ok) TextMain else Dim) }
        }

        SectionTitle("OVERLAY")
        NeonCard {
            PrefSwitch("FPS", { Prefs.showFps }, { Prefs.showFps = it }, ctx)
            PrefSwitch("Frame Time / 1% Low", { Prefs.showFrame }, { Prefs.showFrame = it }, ctx)
            PrefSwitch("CPU", { Prefs.showCpu }, { Prefs.showCpu = it }, ctx)
            PrefSwitch("GPU", { Prefs.showGpu }, { Prefs.showGpu = it }, ctx)
            PrefSwitch("RAM", { Prefs.showRam }, { Prefs.showRam = it }, ctx)
            PrefSwitch("อุณหภูมิ", { Prefs.showTemp }, { Prefs.showTemp = it }, ctx)
            PrefSwitch("กราฟ FPS", { Prefs.showGraph }, { Prefs.showGraph = it }, ctx)
            Text("ความทึบ ${(op * 100).roundToInt()}%", color = Dim, fontSize = 12.sp)
            Slider(value = op, onValueChange = { op = it; Prefs.opacity = it }, valueRange = 0.3f..1f)
            Text("ขนาดตัวอักษร ${ts.roundToInt()}sp", color = Dim, fontSize = 12.sp)
            Slider(value = ts, onValueChange = { ts = it; Prefs.textSize = it }, valueRange = 10f..22f)
            Text("ลากกล่อง Overlay เพื่อย้ายตำแหน่ง (จำตำแหน่งล่าสุดให้)", color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}
