package com.framex.android.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.framex.android.core.Engine
import com.framex.android.core.LiveStats
import com.framex.android.core.Prefs
import com.framex.android.ui.MainActivity
import kotlinx.coroutines.*
import kotlin.math.roundToInt

class MonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var overlay: OverlayController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startFg()
        Engine.start()
        syncOverlay()
        return START_STICKY
    }

    private fun syncOverlay() {
        val want = Prefs.overlayEnabled && Settings.canDrawOverlays(this)
        if (want && overlay == null) overlay = OverlayController(this, scope).also { it.show() }
        if (!want && overlay != null) { overlay?.remove(); overlay = null }
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FRAME X Monitor", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, MonitorService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("FRAME X กำลังตรวจวัดประสิทธิภาพ")
            .setContentText("แตะเพื่อเปิดแอป")
            .setContentIntent(open).setOngoing(true)
            .addAction(0, "หยุด", stop).build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    override fun onDestroy() {
        Engine.stop()
        overlay?.remove(); overlay = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.framex.android.STOP"
        const val ACTION_REFRESH = "com.framex.android.REFRESH"
        private const val CH = "framex_monitor"

        fun start(ctx: Context) {
            androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java))
        }
        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, MonitorService::class.java).setAction(ACTION_STOP))
        }
        /** เรียกหลังเปลี่ยนการตั้งค่า overlay ขณะ service ทำงาน */
        fun refresh(ctx: Context) {
            if (Engine.isRunning()) ctx.startService(Intent(ctx, MonitorService::class.java).setAction(ACTION_REFRESH))
        }
    }
}

private class SparkView(ctx: Context) : View(ctx) {
    var values: List<Float> = emptyList()
    var maxV = 60f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E5FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
    override fun onDraw(c: Canvas) {
        if (values.size < 2) return
        val p = Path()
        values.forEachIndexed { i, v ->
            val x = i * width.toFloat() / (values.size - 1)
            val y = height - (v / maxV).coerceIn(0f, 1f) * height
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        c.drawPath(p, line)
    }
}

/** Overlay จริงด้วย WindowManager (TYPE_APPLICATION_OVERLAY) ลากย้ายได้ ปรับแต่งได้ */
private class OverlayController(private val ctx: Context, private val scope: CoroutineScope) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val d = ctx.resources.displayMetrics.density
    private var root: LinearLayout? = null
    private lateinit var tvFps: TextView
    private lateinit var tvInfo: TextView
    private lateinit var spark: SparkView
    private lateinit var lp: WindowManager.LayoutParams
    private var job: Job? = null

    private fun tv(sp: Float, bold: Boolean) = TextView(ctx).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
        setTextColor(0xFFE6F1FF.toInt())
    }

    fun show() {
        val bg = GradientDrawable().apply {
            cornerRadius = 12 * d; setColor(0xE60A1020.toInt()); setStroke((1 * d).toInt(), 0xFF00E5FF.toInt())
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; background = bg
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        }
        tvFps = tv(22f, true); tvInfo = tv(Prefs.textSize, false)
        spark = SparkView(ctx)
        box.addView(tvFps); box.addView(tvInfo)
        box.addView(spark, LinearLayout.LayoutParams((130 * d).toInt(), (28 * d).toInt()))
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.posX; y = Prefs.posY }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(box, lp)
                }
                MotionEvent.ACTION_UP -> { Prefs.posX = lp.x; Prefs.posY = lp.y }
            }
            true
        }
        wm.addView(box, lp)
        root = box
        job = scope.launch { Engine.state.collect { render(it) } }
    }

    private fun n(v: Float?, suf: String = "") = v?.let { "${it.roundToInt()}$suf" } ?: "N/A"

    private fun render(s: LiveStats) {
        val r = root ?: return
        r.alpha = Prefs.opacity
        tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.textSize)
        tvFps.visibility = if (Prefs.showFps) View.VISIBLE else View.GONE
        val ratio = (s.fps ?: 0f) / s.refreshHz
        tvFps.setTextColor(when { s.fps == null -> 0xFF8FA3C2.toInt(); ratio >= 0.85f -> 0xFF00E5FF.toInt(); ratio >= 0.5f -> 0xFFFFB300.toInt(); else -> 0xFFFF3D71.toInt() })
        tvFps.text = "${n(s.fps)} FPS"
        val sys = s.sys
        val lines = ArrayList<String>()
        if (Prefs.showFrame) lines.add("FT ${s.frameMs?.let { "%.1f".format(it) } ?: "N/A"}ms  1%L ${n(s.low1)}")
        val l2 = ArrayList<String>()
        if (Prefs.showCpu) l2.add("CPU ${n(sys?.cpu, "%")}")
        if (Prefs.showGpu) l2.add("GPU ${n(sys?.gpu, "%")}")
        if (l2.isNotEmpty()) lines.add(l2.joinToString("  "))
        val l3 = ArrayList<String>()
        if (Prefs.showRam && sys != null) l3.add("RAM ${"%.1f".format(sys.ramUsedMb / 1024f)}G")
        if (Prefs.showTemp) l3.add("${(sys?.tempCpu ?: sys?.tempBat)?.let { "%.0f°C".format(it) } ?: "N/A"}")
        if (l3.isNotEmpty()) lines.add(l3.joinToString("  "))
        lines.add("จอ ${s.refreshHz.roundToInt()}Hz")   // Refresh Rate แยกจาก Game FPS
        tvInfo.text = lines.joinToString("\n")
        spark.visibility = if (Prefs.showGraph) View.VISIBLE else View.GONE
        spark.values = s.fpsHistory.takeLast(60); spark.maxV = s.refreshHz; spark.invalidate()
    }

    fun remove() {
        job?.cancel()
        root?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        root = null
    }
}
