package com.framex.android.core

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.framex.android.data.SampleEntity
import com.framex.android.data.SessionEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Exporter {
    private fun dir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }
    private fun na(v: Any?) = v?.toString() ?: "N/A"

    fun csv(ctx: Context, s: SessionEntity, samples: List<SampleEntity>): File {
        val f = File(dir(ctx), "framex_session_${s.id}.csv")
        f.bufferedWriter().use { w ->
            w.write("# app,${s.appName},${s.pkg},refresh_hz,${s.refreshHz},avg_fps,${na(s.avgFps)},1%low,${na(s.low1)},0.1%low,${na(s.low01)}\n")
            w.write("t_sec,game_fps,avg_frame_ms,max_frame_ms,cpu_pct,gpu_pct,ram_mb,cpu_temp_c,battery_temp_c,battery_ma\n")
            samples.forEach {
                w.write(listOf(it.tMs / 1000.0, it.fps, it.avgMs, it.maxMs, it.cpu, it.gpu, it.ramMb, it.tempCpu, it.tempBat, it.batMa)
                    .joinToString(",") { v -> na(v) } + "\n")
            }
        }
        return f
    }

    fun pdf(ctx: Context, s: SessionEntity, samples: List<SampleEntity>, findings: List<Finding>): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = 50f
        p.color = Color.BLACK; p.textSize = 20f; p.isFakeBoldText = true
        c.drawText("FRAME X — Performance Report", 40f, y, p); y += 24f
        p.textSize = 11f; p.isFakeBoldText = false
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(s.startMs))
        fun line(t: String) { c.drawText(t, 40f, y, p); y += 15f }
        fun f(v: Float?) = v?.let { "%.1f".format(it) } ?: "N/A"
        line("${s.appName} (${s.pkg})  ·  $date  ·  ${s.durationMs / 1000}s")
        line("Game FPS avg ${f(s.avgFps)} | min ${f(s.minFps)} | max ${f(s.maxFps)} | 1% low ${f(s.low1)} | 0.1% low ${f(s.low01)}")
        line("Frame time avg ${f(s.avgFrameMs)} ms | stutters ${s.stutters} | fps drops ${s.drops} | display refresh ${"%.0f".format(s.refreshHz)} Hz")
        line("CPU avg ${f(s.avgCpu)}% | GPU avg ${f(s.avgGpu)}% | max temp ${f(s.maxTemp)} C | battery ${na(s.batStart)}% -> ${na(s.batEnd)}%")
        y += 8f

        fun chart(title: String, vals: List<Float>, color: Int) {
            p.color = Color.BLACK; p.isFakeBoldText = true; c.drawText(title, 40f, y, p); p.isFakeBoldText = false
            val top = y + 6f; val h = 90f; val w = 515f
            p.color = Color.LTGRAY; p.style = Paint.Style.STROKE; p.strokeWidth = 1f
            c.drawRect(40f, top, 40f + w, top + h, p)
            if (vals.size > 1) {
                val lo = 0f; val hi = (vals.maxOrNull() ?: 1f).coerceAtLeast(1f)
                val path = Path()
                vals.forEachIndexed { i, v ->
                    val x = 40f + i * w / (vals.size - 1); val yy = top + h - (v - lo) / (hi - lo) * h
                    if (i == 0) path.moveTo(x, yy) else path.lineTo(x, yy)
                }
                p.color = color; p.strokeWidth = 1.5f; c.drawPath(path, p)
                p.style = Paint.Style.FILL; p.color = Color.DKGRAY; p.textSize = 9f
                c.drawText("max ${"%.1f".format(hi)}", 44f, top + 10f, p); p.textSize = 11f
            }
            p.style = Paint.Style.FILL; y = top + h + 22f
        }
        chart("Game FPS", samples.map { it.fps ?: 0f }, Color.rgb(0, 150, 200))
        chart("Frame time (ms, max per second)", samples.map { it.maxMs ?: 0f }, Color.rgb(200, 60, 80))

        p.color = Color.BLACK; p.isFakeBoldText = true; c.drawText("Smart Analyzer", 40f, y, p); y += 8f
        val tp = TextPaint(p).apply { textSize = 10.5f; isFakeBoldText = false }
        for (fd in findings) {
            val text = "[${fd.level}] ${fd.title}\n${fd.evidence}\n=> ${fd.advice}"
            val sl = StaticLayout.Builder.obtain(text, 0, text.length, tp, 515).build()
            if (y + sl.height > 810) break
            c.save(); c.translate(40f, y); sl.draw(c); c.restore(); y += sl.height + 8f
        }
        doc.finishPage(page)
        val file = File(dir(ctx), "framex_report_${s.id}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "ส่งออก").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
