package com.framex.android.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.Choreographer
import android.view.View
import kotlinx.coroutines.*
import kotlin.random.Random

/** Benchmark CPU: sieve of Eratosthenes วนซ้ำในเวลาที่กำหนด นับรอบ/วินาที (single & multi-thread) */
object CpuBench {
    private fun sieve(n: Int): Int {
        val c = BooleanArray(n + 1); var cnt = 0; var i = 2
        while (i <= n) {
            if (!c[i]) { cnt++; var j = i.toLong() * i; while (j <= n) { c[j.toInt()] = true; j += i } }
            i++
        }
        return cnt
    }

    suspend fun run(seconds: Float, threads: Int): Double = coroutineScope {
        val end = System.nanoTime() + (seconds * 1e9).toLong()
        val jobs = (0 until threads).map {
            async(Dispatchers.Default) {
                var rounds = 0L; var sink = 0
                while (System.nanoTime() < end) { sink += sieve(200_000); rounds++ }
                if (sink == Int.MIN_VALUE) println(sink)
                rounds
            }
        }
        jobs.awaitAll().sum() / seconds.toDouble()
    }
}

/**
 * Benchmark กราฟิก: วาดวงกลมโปร่งใสซ้อนกันจำนวนมาก (fill-rate + draw calls) เพิ่มระดับโหลดทีละขั้น
 * วัด frame time จริงด้วย Choreographer ของ View นี้
 */
class BenchView(ctx: Context) : View(ctx) {
    companion object { val STAGES = listOf(300, 1000, 2500, 5000, 9000) }

    private val max = 9000
    private val xs = FloatArray(max); private val ys = FloatArray(max)
    private val vx = FloatArray(max); private val vy = FloatArray(max); private val rs = FloatArray(max)
    private val paints = intArrayOf(0x4400E5FF, 0x442979FF, 0x447C4DFF, 0x4400E676, 0x44FFB300, 0x44FF3D71)
        .map { c -> Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c } }
    var objects = 300
    private var lastNs = 0L
    private var lastDraw = 0L
    private var recording = false
    private var running = false
    private val times = ArrayList<Float>(2000)

    init { keepScreenOn = true }

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (lastNs > 0 && recording) times.add((ns - lastNs) / 1e6f)
            lastNs = ns
            invalidate()
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); running = true; lastNs = 0
        Choreographer.getInstance().postFrameCallback(cb)
    }
    override fun onDetachedFromWindow() {
        running = false; Choreographer.getInstance().removeFrameCallback(cb); super.onDetachedFromWindow()
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val d = resources.displayMetrics.density
        for (i in 0 until max) {
            xs[i] = Random.nextFloat() * w; ys[i] = Random.nextFloat() * h
            vx[i] = (Random.nextFloat() - 0.5f) * 400f * d; vy[i] = (Random.nextFloat() - 0.5f) * 400f * d
            rs[i] = (12f + Random.nextFloat() * 36f) * d
        }
    }
    fun beginRecord() { times.clear(); recording = true }
    fun endRecord(): List<Float> { recording = false; return times.toList() }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastDraw == 0L) 0f else ((now - lastDraw) / 1e9f).coerceAtMost(0.1f)
        lastDraw = now
        val w = width.toFloat(); val h = height.toFloat()
        for (i in 0 until objects) {
            var x = xs[i] + vx[i] * dt; var y = ys[i] + vy[i] * dt
            if (x < 0 || x > w) { vx[i] = -vx[i]; x = x.coerceIn(0f, w) }
            if (y < 0 || y > h) { vy[i] = -vy[i]; y = y.coerceIn(0f, h) }
            xs[i] = x; ys[i] = y
            c.drawCircle(x, y, rs[i], paints[i % 6])
        }
    }
}
