package com.framex.android.core

import kotlin.math.max
import kotlin.math.min

/** Histogram frame time (0.25ms/bucket) ใช้หน่วยความจำคงที่ แม้เล่นหลายชั่วโมง */
class FrameHistogram {
    private val bucketMs = 0.25f
    private val n = 1200
    private val counts = LongArray(n + 1)
    private val sums = DoubleArray(n + 1)
    var total = 0L; private set
    var sumMs = 0.0; private set

    fun add(ms: Float) {
        val i = min((ms / bucketMs).toInt(), n)
        counts[i]++; sums[i] += ms.toDouble(); total++; sumMs += ms
    }

    fun avgFps(): Float? = if (total < 5 || sumMs <= 0.0) null else (1000.0 * total / sumMs).toFloat()
    fun avgFrameMs(): Float? = if (total == 0L) null else (sumMs / total).toFloat()

    /** 1% Low / 0.1% Low = FPS จากค่าเฉลี่ย frame time ของเฟรมที่แย่ที่สุด fraction ส่วน */
    fun lowFps(fraction: Double): Float? {
        if (total < (1.0 / fraction).toLong()) return null
        val need = max(1L, (total * fraction).toLong())
        var taken = 0L
        var acc = 0.0
        var i = n
        while (i >= 0 && taken < need) {
            val c = counts[i]
            if (c > 0) {
                val t = min(need - taken, c)
                acc += sums[i] * (t.toDouble() / c)
                taken += t
            }
            i--
        }
        return if (taken == 0L) null else (1000.0 / (acc / taken)).toFloat()
    }
}

object FrameMath {
    fun avgFps(times: List<Float>): Float? =
        if (times.size < 5) null else (1000.0 * times.size / times.sum()).toFloat()

    fun low1(times: List<Float>): Float? {
        if (times.size < 20) return null
        val worst = times.sortedDescending().take(max(1, times.size / 100))
        return (1000.0 / worst.average()).toFloat()
    }
}

data class SysSnap(
    val cpu: Float?, val cpuFreqMhz: Int?,
    val gpu: Float?, val gpuFreqMhz: Int?,
    val ramUsedMb: Long, val ramTotalMb: Long,
    val tempCpu: Float?, val tempBat: Float?,
    val batPct: Int?, val batMa: Int?,
    val powerSave: Boolean
)

data class LiveStats(
    val running: Boolean = false,
    val pkg: String? = null,
    val appName: String? = null,
    val sourceStatus: String = "ยังไม่เริ่มตรวจวัด",
    val fps: Float? = null,
    val avgFps: Float? = null, val minFps: Float? = null, val maxFps: Float? = null,
    val low1: Float? = null, val low01: Float? = null,
    val frameMs: Float? = null, val frameMsMax: Float? = null,
    val refreshHz: Float = 60f,
    val sys: SysSnap? = null,
    val stutters: Int = 0, val drops: Int = 0,
    val frameTimes: List<Float> = emptyList(),
    val fpsHistory: List<Float> = emptyList(),
    val elapsedSec: Int = 0
)
