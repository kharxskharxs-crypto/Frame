package com.framex.android.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.geometry.Size

val Bg = Color(0xFF070B14)
val Surface1 = Color(0xFF0E1626)
val Surface2 = Color(0xFF16233D)
val Outline = Color(0xFF24344F)
val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val Dim = Color(0xFF8FA3C2)
val TextMain = Color(0xFFE6F1FF)
val Green = Color(0xFF00E676)
val Amber = Color(0xFFFFB300)
val Red = Color(0xFFFF3D71)

private val scheme = darkColorScheme(
    primary = Cyan, onPrimary = Color(0xFF00222A), secondary = Blue,
    background = Bg, surface = Surface1, surfaceVariant = Surface2,
    onSurface = TextMain, onBackground = TextMain, onSurfaceVariant = Dim,
    error = Red, outline = Outline
)

@Composable
fun FrameXTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1),
        border = BorderStroke(1.dp, Outline)
    ) { Column(Modifier.padding(14.dp), content = content) }
}

@Composable
fun Tile(label: String, value: String, modifier: Modifier = Modifier, accent: Color = Cyan) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Surface1)
            .border(1.dp, Outline, RoundedCornerShape(14.dp)).padding(12.dp)
    ) {
        Text(label, color = Dim, fontSize = 11.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            value, color = if (value == "N/A") Dim else accent, fontSize = 19.sp,
            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)

@Composable
fun LineChart(
    values: List<Float>, modifier: Modifier = Modifier, color: Color = Cyan,
    minY: Float? = null, maxY: Float? = null, guides: List<Float> = emptyList(), height: Dp = 120.dp
) {
    Canvas(modifier.fillMaxWidth().height(height)) {
        if (values.size < 2) return@Canvas
        val lo = minY ?: values.minOrNull()!!
        val hi = maxY ?: values.maxOrNull()!!
        val range = maxOf(hi - lo, 0.001f)
        fun y(v: Float) = size.height - ((v.coerceIn(lo, hi) - lo) / range) * size.height
        guides.forEach { g ->
            if (g in lo..hi) drawLine(Outline, Offset(0f, y(g)), Offset(size.width, y(g)), 1.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
        }
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * size.width / (values.size - 1)
            if (i == 0) path.moveTo(x, y(v)) else path.lineTo(x, y(v))
        }
        val fill = Path().apply { addPath(path); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.25f), Color.Transparent)))
        drawPath(path, color, style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun FpsGauge(fps: Float?, maxHz: Float, modifier: Modifier = Modifier) {
    val frac by animateFloatAsState(((fps ?: 0f) / maxHz).coerceIn(0f, 1f), tween(400), label = "g")
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        0.4f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pa"
    )
    Box(modifier.size(230.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val tl = Offset(stroke * 1.4f, stroke * 1.4f)
            val sz = Size(size.width - stroke * 2.8f, size.height - stroke * 2.8f)
            drawArc(Outline, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (frac > 0f) {
                drawArc(Cyan.copy(alpha = 0.18f * pulse), 135f, 270f * frac, false, tl, sz,
                    style = Stroke(stroke * 1.8f, cap = StrokeCap.Round))
                drawArc(Brush.sweepGradient(listOf(Blue, Cyan, Blue), center), 135f, 270f * frac, false, tl, sz,
                    style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                fps?.let { "%.0f".format(it) } ?: "N/A", color = if (fps == null) Dim else Cyan,
                fontSize = 56.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace
            )
            Text("GAME FPS", color = Dim, fontSize = 12.sp, letterSpacing = 3.sp)
        }
    }
}
