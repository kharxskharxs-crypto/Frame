package com.framex.android.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.framex.android.core.*
import com.framex.android.service.MonitorService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private fun go(ctx: Context, i: Intent) {
    try { ctx.startActivity(i) } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        } catch (_: Exception) { }
    }
}

private fun pkgUri(ctx: Context) = Uri.parse("package:${ctx.packageName}")

@Composable
private fun StepCard(
    n: Int, title: String, desc: String, done: Boolean, current: Boolean,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val border = when { done -> Green; current -> Cyan; else -> Outline }
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1),
        border = BorderStroke(if (current) 2.dp else 1.dp, border)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (done) "✅" else "⬜", fontSize = 18.sp)
                Spacer(Modifier.width(8.dp))
                Text("$n. $title", fontWeight = FontWeight.Bold, color = if (done) Green else TextMain, modifier = Modifier.weight(1f))
                if (current && !done) Text("ทำขั้นนี้ต่อ", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text(desc, color = Dim, fontSize = 12.sp)
            if (!done || current) Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = actions)
        }
    }
}

@Composable
private fun PrefSwitch(label: String, get: () -> Boolean, set: (Boolean) -> Unit, ctx: Context) {
    var v by remember { mutableStateOf(get()) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; set(it); MonitorService.refresh(ctx) })
    }
}

@Composable
fun SetupScreen() {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act.lifecycle.addObserver(o); onDispose { act.lifecycle.removeObserver(o) }
    }
    var srcOk by remember { mutableStateOf(Shell.mode == Shell.Mode.DIRECT || Shell.mode == Shell.Mode.BINDER || Shell.mode == Shell.Mode.ROOT) }
    var diagText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var probe by remember { mutableStateOf<List<Pair<String, Boolean>>>(emptyList()) }
    var op by remember { mutableFloatStateOf(Prefs.opacity) }
    var ts by remember { mutableFloatStateOf(Prefs.textSize) }

    // ตรวจสถานะใหม่ทุกครั้งที่กลับเข้ามาที่แอป (ON_RESUME)
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val usageOk = remember(tick) { ForegroundTracker.hasAccess(ctx) }
    val notifOk = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val batteryOk = remember(tick) {
        try { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName) } catch (e: Exception) { false }
    }
    val devOk = remember(tick) {
        try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1 } catch (e: Exception) { false }
    }
    val wifiAdbSupported = Build.VERSION.SDK_INT >= 30
    val wifiAdbOk = remember(tick) {
        try { Settings.Global.getInt(ctx.contentResolver, "adb_wifi_enabled", 0) == 1 } catch (e: Exception) { false }
    }
    val dumpOk = remember(tick) { ctx.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED }
    val ladb = remember { ctx.packageManager.getLaunchIntentForPackage("com.draco.ladb") }
    val cmd = "pm grant ${ctx.packageName} android.permission.DUMP"

    // ลำดับขั้น: ถ้า DUMP ให้แล้ว ขั้นเตรียม adb (5,6) ถือว่าไม่จำเป็นอีก
    val dumpDone = dumpOk || srcOk
    val flags = listOf(overlayOk, usageOk, notifOk, batteryOk, dumpDone || devOk, dumpDone || !wifiAdbSupported || wifiAdbOk, dumpDone, srcOk)
    val firstTodo = flags.indexOfFirst { !it }
    val doneCount = flags.count { it }

    fun runDiag() {
        if (busy) return
        scope.launch {
            busy = true
            val (m, report) = withContext(Dispatchers.IO) { Shell.diagnose(ctx) }
            srcOk = m == Shell.Mode.DIRECT || m == Shell.Mode.BINDER || m == Shell.Mode.ROOT
            diagText = report
            busy = false
        }
    }
    // กลับมาที่แอปหลังให้สิทธิ์ DUMP -> ทดสอบให้อัตโนมัติ
    LaunchedEffect(tick, dumpOk) { if (dumpOk && !srcOk && !busy) runDiag() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("SETUP", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        NeonCard {
            Text("ตั้งค่าแล้ว $doneCount / ${flags.size} ขั้น", fontWeight = FontWeight.Bold, color = if (doneCount == flags.size) Green else TextMain)
            LinearProgressIndicator(progress = { doneCount / flags.size.toFloat() }, Modifier.fillMaxWidth().padding(top = 8.dp),
                color = Cyan, trackColor = Outline)
            Text(if (doneCount == flags.size) "พร้อมใช้งาน ไปแท็บ Monitor แล้วกด START ได้เลย"
            else "ทำตามลำดับจากบนลงล่าง การ์ดที่ขอบสีฟ้าคือขั้นถัดไป ระบบตรวจสถานะให้เองเมื่อกลับมาที่แอป", color = Dim, fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp))
        }

        StepCard(1, "สิทธิ์แสดงทับแอปอื่น", "จำเป็นสำหรับ Overlay ที่ลอยบนเกม", overlayOk, firstTodo == 0) {
            Button(onClick = { go(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri(ctx))) }) { Text("เปิดหน้านี้") }
            OutlinedButton(onClick = { go(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(ctx))) }) { Text("สวิตช์เป็นสีเทา?") }
        }
        StepCard(2, "สิทธิ์ Usage Access", "ใช้ตรวจว่าเกมไหนอยู่ด้านหน้า (ถ้าเลือกแอปเป้าหมายเอง ข้ามได้ แต่แนะนำให้เปิด)", usageOk, firstTodo == 1) {
            Button(onClick = { go(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("เปิดหน้านี้") }
            OutlinedButton(onClick = { go(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(ctx))) }) { Text("สวิตช์เป็นสีเทา?") }
        }
        if (!overlayOk || !usageOk) NeonCard {
            Text("ถ้าสวิตช์กดไม่ได้ (Android 13+ แอปที่ติดตั้งจากไฟล์ APK)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("กด \"สวิตช์เป็นสีเทา?\" แล้วที่หน้ารายละเอียดแอป แตะจุดสามจุดมุมขวาบน เลือก Allow restricted settings (อนุญาตการตั้งค่าที่ถูกจำกัด) จากนั้นกลับมาทำขั้นที่ 1-2 ใหม่",
                color = Dim, fontSize = 12.sp)
        }
        StepCard(3, "การแจ้งเตือน", "ใช้แสดงสถานะตอนกำลังวัด (Android 13+ ต้องอนุญาต)", notifOk, firstTodo == 2) {
            Button(onClick = { go(ctx, Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) }) { Text("เปิดหน้านี้") }
        }
        StepCard(4, "ไม่จำกัดแบตเตอรี่", "กันระบบปิดแอปตอนคุณเล่นเกม (Samsung/Vivo ปิดแอปเบื้องหลังแรง)", batteryOk, firstTodo == 3) {
            Button(onClick = { go(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("เปิดหน้านี้") }
            OutlinedButton(onClick = { go(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(ctx))) }) { Text("หน้ารายละเอียดแอป") }
        }
        StepCard(5, "เปิดตัวเลือกนักพัฒนา", "ต้องมีเพื่อให้สิทธิ์อ่าน FPS ของเกม (ทำครั้งเดียว) ถ้าเมนูยังไม่โผล่ ให้เปิดหน้าข้อมูลโทรศัพท์แล้วแตะ \"หมายเลขบิลด์\" (Build number) 7 ครั้ง",
            dumpDone || devOk, firstTodo == 4) {
            Button(onClick = { go(ctx, Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }) { Text("ข้อมูลโทรศัพท์") }
            OutlinedButton(onClick = { go(ctx, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }) { Text("ตัวเลือกนักพัฒนา") }
        }
        StepCard(6, "เปิด Wireless debugging",
            if (wifiAdbSupported) "เปิดสวิตช์ Wireless debugging ในตัวเลือกนักพัฒนา และต้องต่อ Wi-Fi ไว้"
            else "เครื่องนี้ต่ำกว่า Android 11 ไม่มี Wireless debugging ต้องใช้คอมพิวเตอร์ (ADB ผ่าน USB) หรือ Root แทน",
            dumpDone || !wifiAdbSupported || wifiAdbOk, firstTodo == 5) {
            Button(onClick = { go(ctx, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }) { Text("ตัวเลือกนักพัฒนา") }
        }
        StepCard(7, "ให้สิทธิ์ DUMP (อ่าน FPS เกม)",
            "ครั้งเดียวถาวร ในแอป LADB วางคำสั่งนี้แล้วกด Enter (ไม่มีข้อความขึ้น = สำเร็จ) แล้วกลับมาที่แอปนี้",
            dumpDone, firstTodo == 6) {
            Button(onClick = {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("cmd", cmd))
            }) { Text("คัดลอกคำสั่ง") }
            if (ladb != null) OutlinedButton(onClick = { go(ctx, ladb) }) { Text("เปิด LADB") }
        }
        if (!dumpDone) NeonCard {
            Text("คำสั่งที่ต้องวางใน LADB", fontSize = 12.sp, color = Dim)
            SelectionContainer { Text(cmd, color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)) }
            Text("ใช้คอมพิวเตอร์: adb shell $cmd", color = Dim, fontSize = 11.sp)
            Text(if (ladb == null) "ยังไม่พบแอป LADB ในเครื่อง ค้นหา \"LADB\" ใน Play Store หรือ GitHub (tytydraco/LADB)" else "พบแอป LADB ในเครื่องแล้ว",
                color = Dim, fontSize = 11.sp)
        }
        StepCard(8, "ทดสอบแหล่งข้อมูล FPS",
            if (busy) "กำลังทดสอบ…" else if (srcOk) "ใช้งานได้ — Game FPS พร้อมแล้ว" else if (diagText.isNotEmpty()) "ยังอ่านไม่ได้ ดูรายงานด้านล่าง" else "ระบบจะทดสอบให้เองเมื่อกลับมาหลังให้สิทธิ์ DUMP หรือกดปุ่มทดสอบ",
            srcOk, firstTodo == 7) {
            Button(enabled = !busy, onClick = { runDiag() }) { Text(if (srcOk) "ทดสอบอีกครั้ง" else "ทดสอบ") }
        }
        if (diagText.isNotEmpty()) NeonCard {
            Text("รายงานผลทดสอบ", fontSize = 12.sp, color = Dim)
            SelectionContainer { Text(diagText, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp)) }
            OutlinedButton(onClick = {
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("diag", diagText))
            }) { Text("คัดลอกรายงาน (ส่งให้ผมดูได้)") }
        }

        SectionTitle("เซนเซอร์ที่เครื่องนี้อ่านได้")
        NeonCard {
            Button(onClick = { scope.launch { probe = withContext(Dispatchers.IO) { SystemReader(ctx).probe() } } }) { Text("ตรวจสอบ") }
            probe.forEach { (n, ok) ->
                Text((if (ok) "✅ " else "❌ N/A  ") + n, fontSize = 13.sp, color = if (ok) TextMain else Dim, modifier = Modifier.padding(top = 4.dp))
            }
            if (probe.isNotEmpty()) Text("ตัวที่เป็น N/A คือระบบเครื่องนี้ไม่เปิดให้แอปอ่าน (ปกติ ไม่ใช่ข้อผิดพลาด)", color = Dim, fontSize = 11.sp,
                modifier = Modifier.padding(top = 6.dp))
        }

        SectionTitle("OVERLAY")
        NeonCard {
            PrefSwitch("FPS", { Prefs.showFps }, { Prefs.showFps = it }, ctx)
            PrefSwitch("Frame Time / 1% Low", { Prefs.showFrame }, { Prefs.showFrame = it }, ctx)
            PrefSwitch("CPU", { Prefs.showCpu }, { Prefs.showCpu = it }, ctx)
            PrefSwitch("GPU", { Prefs.showGpu }, { Prefs.showGpu = it }, ctx)
            PrefSwitch("RAM", { Prefs.showRam }, { Prefs.showRam = it }, ctx)
            PrefSwitch("อุณหภูมิ", { Prefs.showTemp }, { Prefs.showTemp = it }, ctx)
            PrefSwitch("กราฟ FPS", { Prefs.showGraph }, { Prefs.showGraph = it }, ctx)
            Text("ความทึบ ${(op * 100).roundToInt()}%", color = Dim, fontSize = 12.sp)
            Slider(value = op, onValueChange = { op = it; Prefs.opacity = it }, valueRange = 0.3f..1f)
            Text("ขนาดตัวอักษร ${ts.roundToInt()}sp", color = Dim, fontSize = 12.sp)
            Slider(value = ts, onValueChange = { ts = it; Prefs.textSize = it }, valueRange = 10f..22f)
            Text("ลากกล่อง Overlay เพื่อย้ายตำแหน่ง (จำตำแหน่งล่าสุดให้)", color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}
