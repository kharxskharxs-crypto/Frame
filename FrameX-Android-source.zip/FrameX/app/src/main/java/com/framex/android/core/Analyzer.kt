package com.framex.android.core

import com.framex.android.data.EventEntity
import com.framex.android.data.SampleEntity
import com.framex.android.data.SessionEntity
import kotlin.math.abs
import kotlin.math.sqrt

enum class Level { OK, INFO, WARN, BAD }
data class Finding(val level: Level, val title: String, val evidence: String, val advice: String)

/** Smart Analyzer: วิเคราะห์จากข้อมูลที่วัดได้จริงในเซสชันเท่านั้น (rule-based) บอกเป็นสาเหตุที่ "เป็นไปได้" */
object Analyzer {
    private fun f0(v: Float) = "%.0f".format(v)
    private fun f1(v: Float) = "%.1f".format(v)

    fun analyze(s: SessionEntity, samples: List<SampleEntity>, events: List<EventEntity>): List<Finding> {
        val out = ArrayList<Finding>()
        val fps = samples.mapNotNull { it.fps }
        val avg = s.avgFps
        if (avg == null || fps.size < 5) {
            return listOf(Finding(Level.INFO, "ข้อมูล FPS ไม่เพียงพอ",
                "เซสชันนี้ไม่มี FPS ของเกม (แหล่งข้อมูล: ${s.source})",
                "ให้สิทธิ์ DUMP ผ่าน ADB หรือใช้ Root แล้วเล่นอย่างน้อย 1 นาที"))
        }
        val hz = s.refreshHz
        val minutes = s.durationMs / 60000f

        // 1) ความสม่ำเสมอของเฟรม
        s.low1?.let { l ->
            if (l < avg * 0.5f) out.add(Finding(Level.BAD, "เฟรมไม่สม่ำเสมอรุนแรง (frame pacing)",
                "1% Low ${f0(l)} FPS ต่ำกว่าครึ่งของค่าเฉลี่ย ${f0(avg)} FPS · Stutter ${s.stutters} ครั้ง",
                "ลดกราฟิก/เอฟเฟกต์, ปิดแอปพื้นหลัง, ลอง Vulkan/OpenGL สลับในเกม ถ้ามีตัวเลือก"))
            else if (l < avg * 0.7f) out.add(Finding(Level.WARN, "มีอาการกระตุกเป็นช่วง",
                "1% Low ${f0(l)} vs เฉลี่ย ${f0(avg)} FPS · Stutter ${s.stutters} ครั้ง",
                "ปิดแอปพื้นหลัง และเช็กว่าเครื่องร้อน/ประหยัดพลังงานหรือไม่"))
        }
        if (s.stutters > 0 && minutes > 0.5f && s.stutters / minutes > 3f)
            out.add(Finding(Level.WARN, "Stutter ถี่",
                "${s.stutters} ครั้งใน ${f1(minutes)} นาที (${f1(s.stutters / minutes)} ครั้ง/นาที)",
                "ดูเวลาที่กระตุกในแท็บวิเคราะห์ ว่าตรงกับฉากโหลด/ต่อสู้หรือไม่ ถ้าเกิดตอนโหลดฉากอาจเป็นการอ่านไฟล์/หน่วยความจำ"))
        if (s.drops > 0)
            out.add(Finding(Level.INFO, "FPS ตกฮวบ ${s.drops} ครั้ง", "FPS ต่ำกว่า 75% ของค่าเฉลี่ย 10 วินาทีก่อนหน้า", "เทียบเวลาที่ตกกับกราฟอุณหภูมิ/โหลดด้านล่าง"))

        // 2) เกมถูกจำกัดเฟรม / ไม่ตรงกับ Refresh Rate
        val sd = sqrt(fps.map { (it - avg) * (it - avg) }.average()).toFloat()
        for (d in listOf(2, 3, 4)) {
            val target = hz / d
            if (target >= 20f && abs(avg - target) / target < 0.08f && sd < target * 0.1f && avg < hz * 0.9f) {
                out.add(Finding(Level.INFO, "FPS นิ่งที่ ~${f0(target)} (จอ ${f0(hz)} Hz ÷ $d)",
                    "เฉลี่ย ${f0(avg)} FPS ส่วนเบี่ยงเบน ${f1(sd)}",
                    "มักเป็นการจำกัดเฟรมของเกม หรือโหมดประหยัดพลังงาน ลองเพิ่มตั้งค่า Frame Rate ในเกม"))
                break
            }
        }

        // 3) Thermal
        val temps = samples.mapNotNull { it.tempCpu ?: it.tempBat }
        if (fps.size >= 60) {
            val q = fps.size / 4
            val first = fps.take(q).average().toFloat()
            val last = fps.takeLast(q).average().toFloat()
            val drop = if (first > 0) (first - last) / first else 0f
            if (drop > 0.12f && temps.size >= q * 2) {
                val dT = (temps.takeLast(q).average() - temps.take(q).average()).toFloat()
                if (dT >= 2f || (s.maxTemp ?: 0f) >= 42f)
                    out.add(Finding(Level.WARN, "อาจเกิด Thermal Throttling",
                        "FPS ช่วงต้น ${f0(first)} → ช่วงท้าย ${f0(last)} (-${f0(drop * 100)}%) อุณหภูมิเพิ่ม ${f1(dT)}°C",
                        "พักเครื่อง/ถอดเคส/ใช้พัดลมระบายความร้อน ลดกราฟิก หรือจำกัด FPS ให้ต่ำลงเพื่อให้เสถียรกว่า"))
            }
        }
        s.maxTemp?.let { t ->
            if (t >= 45f) out.add(Finding(Level.BAD, "อุณหภูมิสูงมาก", "สูงสุด ${f1(t)}°C", "หยุดเล่นให้เครื่องเย็นลง และหยุดชาร์จระหว่างเล่น"))
            else if (t >= 41f) out.add(Finding(Level.WARN, "อุณหภูมิค่อนข้างสูง", "สูงสุด ${f1(t)}°C", "ระวังการลดสัญญาณนาฬิกา (throttle) ถ้าเล่นต่อเนื่อง"))
        }

        // 4) คอขวด CPU / GPU
        val cpu = s.avgCpu; val gpu = s.avgGpu
        if (gpu != null && gpu >= 90f) out.add(Finding(Level.WARN, "GPU เป็นคอขวด", "โหลด GPU เฉลี่ย ${f0(gpu)}%", "ลดความละเอียด เงา Anti-aliasing หรือ Graphics preset ในเกม"))
        if (cpu != null && cpu >= 85f) out.add(Finding(Level.WARN, "CPU โหลดสูง", "โหลด CPU เฉลี่ย ${f0(cpu)}%", "ปิดแอปพื้นหลัง ลดจำนวนตัวละคร/ฟิสิกส์ในเกม"))
        if (cpu == null && gpu == null)
            out.add(Finding(Level.INFO, "ระบุคอขวด CPU/GPU ไม่ได้",
                "เครื่องนี้ไม่เปิดให้แอปอ่านโหลด CPU/GPU (N/A)", "ต้องใช้ Root/ADB shell จึงจะอ่านค่าเหล่านี้ได้"))

        // 5) RAM
        if (s.ramTotalMb > 0 && samples.isNotEmpty()) {
            val used = samples.map { it.ramMb }.average() / s.ramTotalMb
            if (used > 0.88) out.add(Finding(Level.WARN, "หน่วยความจำเหลือน้อย",
                "ใช้ RAM เฉลี่ย ${f0((used * 100).toFloat())}% ของ ${s.ramTotalMb} MB", "ปิดแอปพื้นหลัง ระบบอาจฆ่าโปรเซสและทำให้เกมกระตุก"))
        }

        // 6) ประหยัดพลังงาน / แบตเตอรี่
        if (s.powerSave) out.add(Finding(Level.WARN, "เปิดโหมดประหยัดแบตเตอรี่ระหว่างเล่น", "ระบบอาจจำกัดสัญญาณนาฬิกาและ FPS", "ปิด Battery Saver แล้ววัดซ้ำ"))
        if (s.batStart != null && s.batEnd != null && minutes >= 5f) {
            val perHour = (s.batStart - s.batEnd) / (minutes / 60f)
            if (perHour >= 25f) out.add(Finding(Level.INFO, "แบตเตอรี่ลดเร็ว", "ประมาณ ${f0(perHour)}% ต่อชั่วโมง (${s.batStart}% → ${s.batEnd}%)", "ลดความสว่างจอ/กราฟิก หรือจำกัด FPS"))
        }

        if (out.none { it.level == Level.WARN || it.level == Level.BAD })
            out.add(0, Finding(Level.OK, "ประสิทธิภาพเสถียร",
                "เฉลี่ย ${f0(avg)} FPS · 1% Low ${s.low1?.let { f0(it) } ?: "N/A"} · Stutter ${s.stutters} ครั้ง", "ไม่พบปัญหาจากข้อมูลที่วัดได้"))
        return out
    }
}
