package com.framex.android.core

import android.content.Context
import android.os.SystemClock
import com.framex.android.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.max
import kotlin.math.min

/** บันทึกข้อมูลของ 1 เซสชัน (เกม 1 แอป) */
private class Rec(val pkg: String, val appName: String, val refreshHz: Float, val source: String) {
    val startMs = System.currentTimeMillis()
    val startElapsed = SystemClock.elapsedRealtime()
    val hist = FrameHistogram()
    val samples = ArrayList<SampleEntity>()
    val events = ArrayList<EventEntity>()
    private val ring = FloatArray(30); private var ringN = 0
    private val chart = FloatArray(240); private var chartN = 0
    private var prevTs = 0L
    var started = false
    var secFrames = 0; var secSum = 0f; var secMax = 0f; var secStart = startElapsed
    val fpsList = ArrayList<Float>()
    var fpsSamples = 0
    var lastFps: Float? = null; var lastAvgMs: Float? = null; var lastMaxMs: Float? = null
    var stutters = 0; var drops = 0; private var inDrop = false
    private var cpuSum = 0.0; private var cpuN = 0; private var gpuSum = 0.0; private var gpuN = 0
    private var maxTemp: Float? = null
    private var batStart: Int? = null; private var batEnd: Int? = null
    private var powerSave = false; private var ramTotal = 0L
    var snap: SysSnap? = null

    fun onFrame(ts: Long, nowElapsed: Long) {
        val prev = prevTs; prevTs = ts
        if (prev <= 0 || ts <= prev) return
        val dt = (ts - prev) / 1_000_000f
        if (dt > 1000f) return
        started = true
        hist.add(dt); secFrames++; secSum += dt; if (dt > secMax) secMax = dt
        chart[chartN % 240] = dt; chartN++
        if (ringN >= 10) {
            val cnt = min(ringN, ring.size)
            var s = 0f
            for (i in 0 until cnt) s += ring[i]
            val avg = s / cnt
            // Stutter = เฟรมช้ากว่าค่าเฉลี่ยล่าสุด > 2 เท่า และช้ากว่า 20ms
            if (dt > 2f * avg && dt > 20f) {
                val t = nowElapsed - startElapsed
                val last = events.lastOrNull()
                if (last != null && last.type == "STUTTER" && t - last.tMs < 250) {
                    if (dt > last.value) events[events.size - 1] = last.copy(value = dt)
                } else {
                    stutters++
                    if (events.size < 3000)
                        events.add(EventEntity(sessionId = 0, tMs = t, type = "STUTTER", value = dt,
                            note = if (dt > 3f * avg && dt > 50f) "severe" else ""))
                }
            }
        }
        ring[ringN % ring.size] = dt; ringN++
    }

    fun recentFrames(): List<Float> {
        val n = min(chartN, 240)
        val out = ArrayList<Float>(n)
        for (i in chartN - n until chartN) out.add(chart[i % 240])
        return out
    }

    fun closeSecond(dtSec: Float, s: SysSnap, hasSource: Boolean, now: Long) {
        snap = s
        val fps = if (hasSource && started) secFrames / dtSec else null
        val t = now - startElapsed
        samples.add(SampleEntity(
            sessionId = 0, tMs = t, fps = fps,
            avgMs = if (secFrames > 0) secSum / secFrames else null,
            maxMs = if (secFrames > 0) secMax else null,
            cpu = s.cpu, gpu = s.gpu, ramMb = s.ramUsedMb,
            tempCpu = s.tempCpu, tempBat = s.tempBat, batMa = s.batMa))
        lastFps = fps
        lastAvgMs = if (secFrames > 0) secSum / secFrames else null
        lastMaxMs = if (secFrames > 0) secMax else null
        if (fps != null) {
            fpsSamples++
            // FPS Drop = FPS วินาทีนี้ต่ำกว่า 75% ของค่าเฉลี่ย 10 วินาทีก่อนหน้า
            if (fpsList.size >= 10) {
                val avg10 = fpsList.takeLast(10).average().toFloat()
                if (avg10 > 20f) {
                    if (fps < avg10 * 0.75f) {
                        if (!inDrop) { inDrop = true; drops++
                            events.add(EventEntity(sessionId = 0, tMs = t, type = "DROP", value = fps, note = "avg10=${"%.0f".format(avg10)}")) }
                    } else if (fps >= avg10 * 0.85f) inDrop = false
                }
            }
            fpsList.add(fps)
        }
        s.cpu?.let { cpuSum += it; cpuN++ }
        s.gpu?.let { gpuSum += it; gpuN++ }
        (s.tempCpu ?: s.tempBat)?.let { maxTemp = max(maxTemp ?: it, it) }
        if (batStart == null) batStart = s.batPct
        batEnd = s.batPct; powerSave = powerSave || s.powerSave; ramTotal = s.ramTotalMb
        secFrames = 0; secSum = 0f; secMax = 0f; secStart = now
    }

    fun minFps(): Float? = fpsList.filter { it > 0.5f }.minOrNull()
    fun maxFps(): Float? = fpsList.maxOrNull()

    fun toEntity(now: Long) = SessionEntity(
        pkg = pkg, appName = appName, startMs = startMs, durationMs = now - startElapsed,
        avgFps = hist.avgFps(), minFps = minFps(), maxFps = maxFps(),
        low1 = hist.lowFps(0.01), low01 = hist.lowFps(0.001), avgFrameMs = hist.avgFrameMs(),
        stutters = stutters, drops = drops, refreshHz = refreshHz, source = source,
        avgCpu = if (cpuN > 0) (cpuSum / cpuN).toFloat() else null,
        avgGpu = if (gpuN > 0) (gpuSum / gpuN).toFloat() else null,
        maxTemp = maxTemp, batStart = batStart, batEnd = batEnd,
        powerSave = powerSave, ramTotalMb = ramTotal)
}

object Engine {
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val _state = MutableStateFlow(LiveStats())
    val state: StateFlow<LiveStats> = _state.asStateFlow()
    private val _events = MutableStateFlow<List<EventEntity>>(emptyList())
    val events: StateFlow<List<EventEntity>> = _events.asStateFlow()

    fun init(c: Context) { app = c.applicationContext }
    fun isRunning() = job?.isActive == true
    fun start() { if (!isRunning()) job = scope.launch { loop() } }
    fun stop() { job?.cancel() }

    private suspend fun finish(r: Rec) {
        if (r.fpsSamples < 5) return
        withContext(NonCancellable) {
            val dao = Db.dao
            val id = dao.insertSession(r.toEntity(SystemClock.elapsedRealtime()))
            dao.insertSamples(r.samples.map { it.copy(sessionId = id) })
            dao.insertEvents(r.events.map { it.copy(sessionId = id) })
        }
    }

    private suspend fun loop() {
        val sys = SystemReader(app)
        val fg = ForegroundTracker(app)
        val sf = SurfaceFlingerSource()
        val refresh = sys.refreshRate()
        var rec: Rec? = null
        var snap = sys.snapshot()
        var lastSys = 0L
        _state.value = LiveStats(running = true, refreshHz = refresh, sys = snap)
        _events.value = emptyList()
        try {
            while (currentCoroutineContext().isActive) {
                val t0 = SystemClock.elapsedRealtime()
                val target = Prefs.target
                val fgPkg = fg.foreground() ?: target
                val pause = fgPkg == null || fg.isIgnored(fgPkg) || (target != null && target != fgPkg)

                if (pause) {
                    rec?.let { finish(it) }; rec = null; sf.reset()
                    if (t0 - lastSys >= 1000) { snap = sys.snapshot(); lastSys = t0 }
                    val msg = if (!ForegroundTracker.hasAccess(app) && target == null)
                        "ต้องเปิด Usage Access เพื่อตรวจจับเกมอัตโนมัติ (หรือเลือกแอปเป้าหมายเอง)"
                    else "รอเกม/แอปเป้าหมายขึ้นมาอยู่ด้านหน้า…"
                    _state.update { it.copy(running = true, pkg = null, appName = null, sourceStatus = msg, fps = null,
                        refreshHz = refresh, sys = snap, frameTimes = emptyList()) }
                    delay(1000); continue
                }

                var r = rec
                if (r == null || r.pkg != fgPkg) {
                    r?.let { finish(it) }
                    sf.reset()
                    r = Rec(fgPkg!!, fg.label(fgPkg), refresh, "SurfaceFlinger")
                    rec = r
                    _events.value = emptyList()
                }

                val frames = sf.poll(r.pkg)
                frames?.forEach { r.onFrame(it, t0) }

                if (t0 - r.secStart >= 1000) {
                    snap = sys.snapshot()
                    r.closeSecond((t0 - r.secStart) / 1000f, snap, frames != null, t0)
                    _events.value = r.events.toList()
                }
                val low1 = r.hist.lowFps(0.01)
                _state.value = LiveStats(
                    running = true, pkg = r.pkg, appName = r.appName, sourceStatus = sf.status,
                    fps = r.lastFps, avgFps = r.hist.avgFps(), minFps = r.minFps(), maxFps = r.maxFps(),
                    low1 = low1, low01 = r.hist.lowFps(0.001),
                    frameMs = r.lastAvgMs, frameMsMax = r.lastMaxMs, refreshHz = refresh,
                    sys = r.snap ?: snap, stutters = r.stutters, drops = r.drops,
                    frameTimes = r.recentFrames(), fpsHistory = r.fpsList.takeLast(120),
                    elapsedSec = ((t0 - r.startElapsed) / 1000).toInt())
                delay(max(50L, 500L - (SystemClock.elapsedRealtime() - t0)))
            }
        } finally {
            rec?.let { finish(it) }
            _state.update { it.copy(running = false, fps = null) }
        }
    }
}
