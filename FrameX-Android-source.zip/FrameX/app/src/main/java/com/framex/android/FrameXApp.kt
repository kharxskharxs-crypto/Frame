package com.framex.android

import android.app.Application
import com.framex.android.core.Engine
import com.framex.android.core.Prefs
import com.framex.android.data.Db

class FrameXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Db.init(this)
        Engine.init(this)
    }
}
