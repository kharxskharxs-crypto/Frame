package com.framex.android.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.PowerManager
import android.view.Display
import java.io.File
import kotlin.math.abs

/** อ่านค่าจริงจากระบบ ถ้าอ่านไม่ได้คืน null (UI แสดง N/A) ไม่มีการสร้างตัวเลขปลอม */
class SystemReader(private val ctx: Context) {
    private val am = ctx.getSystemService(ActivityManager::class.java)
    private val pm = ctx.getSystemService(PowerManager::class.java)
    private val bm = ctx.getSystemService(BatteryManager::class.java)
    private var prevTotal = 0L
    private var prevIdle = 0L
    private val cores = Runtime.getRuntime().availableProcessors()
    private val num = Regex("-?\\d+(\\.\\d+)?")
    private val MB = 1024L * 1024L

    private val cpuThermal: File? by lazy {
        File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
            ?.sortedBy { it.name }?.firstOrNull { z ->
                val type = text(File(z, "type"))?.trim()?.lowercase() ?: return@firstOrNull false
                Regex("cpu|soc|tsens|cpuss|mtk|big|little").containsMatchIn(type) &&
                    readTemp(File(z, "temp")) != null
            }?.let { File(it, "temp") }
    }
    private val gpuDevfreq: File? by lazy {
        File("/sys/class/devfreq").listFiles()?.firstOrNull {
            it.name.contains("gpu", true) || it.name.contains("mali", true) || it.name.contains("kgsl", true)
        }
    }

    private fun text(f: File): String? = try { f.bufferedReader().use { it.readText() } } catch (e: Exception) { null }
    private fun number(path: String): Float? = number(File(path))
    private fun number(f: File): Float? = text(f)?.let { num.find(it)?.value?.toFloatOrNull() }
    private fun readTemp(f: File): Float? {
        val v = number(f) ?: return null
        val c = if (v > 1000f) v / 1000f else v
        return if (c in 10f..120f) c else null
    }
    private fun toMhz(v: Float): Int = when {
        v > 1_000_000f -> (v / 1_000_000f).toInt()   // Hz
        v > 1_000f -> (v / 1_000f).toInt()           // kHz
        else -> v.toInt()
    }

    fun refreshRate(): Float = try {
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).refreshRate
    } catch (e: Exception) { 60f }

    private fun cpuUsage(): Float? {
        var line = try { File("/proc/stat").bufferedReader().use { it.readLine() } } catch (e: Exception) { null }
        if (line == null && Shell.mode == Shell.Mode.ROOT) line = Shell.exec("head -n 1 /proc/stat", root = true)?.lineSequence()?.firstOrNull()
        if (line == null || !line.startsWith("cpu")) return null
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) return null
        val idle = p[3] + p[4]
        val total = p.take(8).sum()
        val dT = total - prevTotal
        val dI = idle - prevIdle
        val first = prevTotal == 0L
        prevTotal = total; prevIdle = idle
        if (first || dT <= 0) return null
        return ((dT - dI) * 100f / dT).coerceIn(0f, 100f)
    }

    private fun cpuFreq(): Int? {
        var sum = 0L; var n = 0
        for (i in 0 until cores) {
            val v = number("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq") ?: continue
            sum += v.toLong(); n++
        }
        return if (n == 0) null else (sum / n / 1000).toInt()
    }

    private fun gpu(): Pair<Float?, Int?> {
        var load = number("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")
        if (load == null) {
            val t = text(File("/sys/class/kgsl/kgsl-3d0/gpubusy"))?.trim()?.split(Regex("\\s+"))?.mapNotNull { it.toLongOrNull() }
            if (t != null && t.size >= 2 && t[1] > 0) load = t[0] * 100f / t[1]
        }
        if (load == null) load = number("/sys/kernel/gpu/gpu_busy")
        if (load == null) gpuDevfreq?.let { load = number(File(it, "load")) }
        var f = number("/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq")?.let { toMhz(it) }
        if (f == null) f = number("/sys/kernel/gpu/gpu_clock")?.toInt()
        if (f == null) gpuDevfreq?.let { f = number(File(it, "cur_freq"))?.let { v -> toMhz(v) } }
        return load?.coerceIn(0f, 100f) to f
    }

    fun snapshot(): SysSnap {
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val total = mi.totalMem / MB
        val used = total - mi.availMem / MB
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else null
        val tBat = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }?.let { it / 10f }
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // บางเครื่องรายงานเป็น µA บางเครื่องเป็น mA
        val ma = if (raw == Int.MIN_VALUE || raw == 0) null else if (abs(raw) > 20000) abs(raw) / 1000 else abs(raw)
        val (gl, gf) = gpu()
        return SysSnap(
            cpu = cpuUsage(), cpuFreqMhz = cpuFreq(), gpu = gl, gpuFreqMhz = gf,
            ramUsedMb = used, ramTotalMb = total,
            tempCpu = cpuThermal?.let { readTemp(it) }, tempBat = tBat,
            batPct = pct, batMa = ma, powerSave = pm.isPowerSaveMode
        )
    }

    /** ตรวจว่าเครื่องนี้อ่านเซนเซอร์อะไรได้บ้าง (ใช้ในหน้าตั้งค่า) */
    fun probe(): List<Pair<String, Boolean>> {
        cpuUsage(); Thread.sleep(400)
        val s = snapshot()
        return listOf(
            "CPU Usage (/proc/stat)" to (s.cpu != null),
            "CPU Frequency" to (s.cpuFreqMhz != null),
            "GPU Usage" to (s.gpu != null),
            "GPU Frequency" to (s.gpuFreqMhz != null),
            "CPU Temperature (thermal zone)" to (s.tempCpu != null),
            "Battery Temperature" to (s.tempBat != null),
            "Battery Current" to (s.batMa != null),
            "RAM" to true
        )
    }
}
