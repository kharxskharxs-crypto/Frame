package com.framex.android.core

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** อ่านข้อมูลจาก dumpsys: DIRECT (sh dumpsys) -> BINDER (เรียก dump ตรงผ่าน Binder) -> ROOT (su) */
object Shell {
    enum class Mode { UNKNOWN, DIRECT, BINDER, ROOT, NONE }

    @Volatile var mode = Mode.UNKNOWN
    @Volatile private var lastProbe = 0L
    private val watchdog = Executors.newSingleThreadScheduledExecutor { r -> Thread(r).apply { isDaemon = true } }

    private fun execFull(cmd: String, root: Boolean, timeoutMs: Long = 2500): Pair<Int, String> = try {
        val p = ProcessBuilder(if (root) listOf("su", "-c", cmd) else listOf("sh", "-c", cmd))
            .redirectErrorStream(true).start()
        val f = watchdog.schedule(Runnable { p.destroyForcibly() }, timeoutMs, TimeUnit.MILLISECONDS)
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor(); f.cancel(false)
        code to out
    } catch (e: Exception) { -1 to "EXC: $e" }

    fun exec(cmd: String, root: Boolean = false, timeoutMs: Long = 2500): String? {
        val r = execFull(cmd, root, timeoutMs)
        return if (r.first == -1 && r.second.startsWith("EXC:")) null else r.second
    }

    /** รายการเลเยอร์จริงจะมีเครื่องหมาย # (เช่น StatusBar#0) และต้องไม่มีข้อความปฏิเสธสิทธิ์ */
    private fun usable(s: String?): Boolean {
        if (s == null) return false
        val low = s.lowercase()
        if (!s.contains("#")) return false
        return listOf("permission denial", "permission denied", "can't find service", "not found").none { low.contains(it) }
    }

    private fun head(s: String) = s.trim().replace('\n', ' ').take(160)
    private fun describe(p: Pair<Int, String>) = "exit=${p.first} · ${p.second.lines().size} บรรทัด → ${head(p.second)}"

    private fun detect(sb: StringBuilder?): Mode {
        val cmd = "dumpsys SurfaceFlinger --list"
        val a = execFull(cmd, false)
        sb?.appendLine("[1] shell dumpsys: ${describe(a)}")
        if (usable(a.second)) return Mode.DIRECT
        val (bt, be) = BinderDump.dump("SurfaceFlinger", listOf("--list"))
        sb?.appendLine("[2] binder dump: " + if (bt != null) "${bt.lines().size} บรรทัด → ${head(bt)}" else "ล้มเหลว: $be")
        if (usable(bt)) return Mode.BINDER
        val r = execFull(cmd, true)
        sb?.appendLine("[3] su (root): ${describe(r)}")
        if (usable(r.second)) return Mode.ROOT
        return Mode.NONE
    }

    fun resolve(force: Boolean = false): Mode {
        val now = SystemClock.elapsedRealtime()
        if (force || mode == Mode.UNKNOWN || (mode == Mode.NONE && now - lastProbe > 15000)) {
            lastProbe = now
            mode = detect(null)
        }
        return mode
    }

    /** ทดสอบพร้อมรายงานละเอียด (ใช้ในหน้า Setup) */
    fun diagnose(ctx: Context): Pair<Mode, String> {
        val sb = StringBuilder()
        val granted = ctx.checkSelfPermission(android.Manifest.permission.DUMP) == android.content.pm.PackageManager.PERMISSION_GRANTED
        sb.appendLine("${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        sb.appendLine("สิทธิ์ DUMP: ${if (granted) "ได้รับแล้ว" else "ยังไม่ได้รับ"} · uid=${Process.myUid()}")
        val dom = try { java.io.File("/proc/self/attr/current").readText().trim() } catch (e: Exception) { "อ่านไม่ได้" }
        sb.appendLine("SELinux: $dom")
        val m = detect(sb)
        mode = m; lastProbe = SystemClock.elapsedRealtime()
        sb.appendLine("ผล: ${m.name}")
        if (m == Mode.NONE) sb.appendLine(if (!granted) "สาเหตุที่เป็นไปได้: ยังไม่ได้ให้สิทธิ์ DUMP" else "สาเหตุที่เป็นไปได้: ระบบ/SELinux ของรอมนี้บล็อกการอ่าน SurfaceFlinger")
        return m to sb.toString()
    }

    fun run(cmd: String): String? = when (mode) {
        Mode.DIRECT -> exec(cmd)
        Mode.ROOT -> exec(cmd, root = true)
        Mode.BINDER -> runBinder(cmd)
        else -> null
    }

    private fun runBinder(cmd: String): String? {
        val toks = Regex("'([^']*)'|(\\S+)").findAll(cmd).map { m -> m.groupValues[1].ifEmpty { m.groupValues[2] } }.toList()
        if (toks.size < 2 || toks[0] != "dumpsys") return null
        return BinderDump.dump(toks[1], toks.drop(2)).first
    }
}

/** เรียก IBinder.dump() ของบริการระบบโดยตรง (ต้องมีสิทธิ์ DUMP) ไม่ต้องสร้างโปรเซส dumpsys */
object BinderDump {
    fun dump(service: String, args: List<String>, timeoutMs: Long = 2500): Pair<String?, String?> {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, service) as? IBinder
                ?: return Pair(null, "ไม่พบบริการ $service")
            val pipe = ParcelFileDescriptor.createPipe()
            val rd = pipe[0]
            val wr = pipe[1]
            var err: String? = null
            val t = Thread {
                try { binder.dump(wr.fileDescriptor, args.toTypedArray()) } catch (e: Throwable) { err = e.toString() }
                finally { try { wr.close() } catch (_: Exception) { } }
            }
            t.isDaemon = true; t.start()
            val killer = Thread { try { Thread.sleep(timeoutMs); wr.close() } catch (_: Exception) { } }
            killer.isDaemon = true; killer.start()
            val text = ParcelFileDescriptor.AutoCloseInputStream(rd).bufferedReader().use { it.readText() }
            killer.interrupt()
            if (text.isBlank()) Pair(null, err ?: "ไม่มีข้อมูลตอบกลับ") else Pair(text, err)
        } catch (e: Throwable) { Pair(null, e.toString()) }
    }
}

/**
 * อ่านเวลา present จริงของแต่ละเฟรมเกมจาก `dumpsys SurfaceFlinger --latency <layer>`
 * (คอลัมน์ที่ 2 = actualPresentTime) -> ได้ Game FPS และ Frame Time ของเกมอื่นที่เปิดอยู่จริง
 */
class SurfaceFlingerSource {
    var status = "—"; private set
    private var layer: String? = null
    private var layerPkg: String? = null
    private var lastTs = 0L
    private var empty = 0
    private val ws = Regex("\\s+")

    fun reset() { layer = null; layerPkg = null; lastTs = 0; empty = 0 }

    private fun parse(text: String): List<Long> {
        val out = ArrayList<Long>(128)
        for (l in text.lineSequence().drop(1)) {
            val p = l.trim().split(ws)
            if (p.size < 3) continue
            val a = p[1].toLongOrNull() ?: continue
            if (a <= 0L || a == Long.MAX_VALUE) continue
            out.add(a)
        }
        return out
    }

    private fun findLayer(pkg: String): String? {
        val list = Shell.run("dumpsys SurfaceFlinger --list") ?: return null
        val cands = list.lines().map { it.trim() }
            .filter { it.contains(pkg) && !it.contains("Background for", true) && !it.contains("Bounds for", true) }
            .sortedByDescending { if (it.contains("SurfaceView")) 1 else 0 }
            .take(4)
        var best: String? = null
        var bestTs = 0L
        for (c in cands) {
            val newest = parse(Shell.run("dumpsys SurfaceFlinger --latency '$c'") ?: continue).maxOrNull() ?: continue
            if (newest > bestTs) { best = c; bestTs = newest }
        }
        return best
    }

    /** null = ไม่มีแหล่งข้อมูล (แสดง N/A), list = เฟรมใหม่ตั้งแต่ poll ครั้งก่อน (timestamp ns) */
    fun poll(pkg: String): List<Long>? {
        val mode = Shell.resolve()
        if (mode == Shell.Mode.NONE) {
            status = "N/A — ต้องให้สิทธิ์ DUMP ผ่าน ADB หรือใช้ Root (ดูแท็บตั้งค่า)"
            return null
        }
        if (layer == null || layerPkg != pkg) {
            layer = findLayer(pkg); layerPkg = pkg; lastTs = 0
            if (layer == null) { status = "ไม่พบเลเยอร์ภาพของ $pkg (เกมอาจยังไม่แสดงผล)"; return null }
        }
        val out = Shell.run("dumpsys SurfaceFlinger --latency '$layer'")
        if (out == null) { status = "อ่าน SurfaceFlinger ไม่สำเร็จ"; layer = null; return null }
        val ts = parse(out)
        if (ts.isEmpty()) {
            if (++empty >= 4) { layer = null; empty = 0 }
            status = "รอเฟรมจากเกม…"
            return null
        }
        empty = 0
        status = "OK · SurfaceFlinger (${when (mode) { Shell.Mode.ROOT -> "root"; Shell.Mode.BINDER -> "DUMP/binder"; else -> "DUMP" }})"
        if (lastTs == 0L) { lastTs = ts.maxOrNull()!!; return emptyList() }
        val fresh = ts.filter { it > lastTs }.sorted()
        if (fresh.isNotEmpty()) lastTs = fresh.last()
        return fresh
    }
}

/** หาแอปที่อยู่ด้านหน้าด้วย UsageStatsManager (ต้องเปิด Usage Access) */
class ForegroundTracker(private val ctx: Context) {
    private val usm = ctx.getSystemService(UsageStatsManager::class.java)
    private var last: String? = null
    private var lastQuery = 0L

    private val ignored: Set<String> by lazy {
        val s = hashSetOf(ctx.packageName, "com.android.systemui")
        val pm = ctx.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.queryIntentActivities(home, 0).forEach { s.add(it.activityInfo.packageName) }
        s
    }

    fun isIgnored(pkg: String) = pkg in ignored

    @Suppress("DEPRECATION")
    fun foreground(): String? {
        try {
            val now = System.currentTimeMillis()
            val begin = if (lastQuery == 0L) now - 3_600_000L else lastQuery - 1000
            val ev = usm.queryEvents(begin, now) ?: return last
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
                else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == last) last = null
            }
            lastQuery = now
        } catch (_: Exception) { }
        return last
    }

    fun label(pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    companion object {
        @Suppress("DEPRECATION")
        fun hasAccess(ctx: Context): Boolean = try {
            val ops = ctx.getSystemService(AppOpsManager::class.java)
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }
    }
}
