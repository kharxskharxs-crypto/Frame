package com.framex.android.core

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** รันคำสั่ง shell: DIRECT (แอปที่ได้สิทธิ์ DUMP ผ่าน ADB) หรือ ROOT (su) */
object Shell {
    enum class Mode { UNKNOWN, DIRECT, ROOT, NONE }

    @Volatile var mode = Mode.UNKNOWN
    @Volatile private var lastProbe = 0L
    private val watchdog = Executors.newSingleThreadScheduledExecutor { r -> Thread(r).apply { isDaemon = true } }

    fun exec(cmd: String, root: Boolean = false, timeoutMs: Long = 2500): String? = try {
        val p = ProcessBuilder(if (root) listOf("su", "-c", cmd) else listOf("sh", "-c", cmd))
            .redirectErrorStream(true).start()
        val f = watchdog.schedule(Runnable { p.destroyForcibly() }, timeoutMs, TimeUnit.MILLISECONDS)
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(); f.cancel(false)
        out
    } catch (e: Exception) { null }

    private fun usable(s: String?) = s != null && s.lines().size > 1 &&
        !s.contains("Permission Denial", true) && !s.contains("denied", true) && !s.contains("not found", true)

    fun resolve(force: Boolean = false): Mode {
        val now = SystemClock.elapsedRealtime()
        if (force || mode == Mode.UNKNOWN || (mode == Mode.NONE && now - lastProbe > 15000)) {
            lastProbe = now
            val cmd = "dumpsys SurfaceFlinger --list"
            mode = when {
                usable(exec(cmd)) -> Mode.DIRECT
                usable(exec(cmd, root = true)) -> Mode.ROOT
                else -> Mode.NONE
            }
        }
        return mode
    }

    fun run(cmd: String): String? = when (mode) {
        Mode.DIRECT -> exec(cmd)
        Mode.ROOT -> exec(cmd, root = true)
        else -> null
    }
}

/**
 * อ่านเวลา present จริงของแต่ละเฟรมเกมจาก `dumpsys SurfaceFlinger --latency <layer>`
 * (คอลัมน์ที่ 2 = actualPresentTime) -> ได้ Game FPS และ Frame Time ของเกมอื่นที่เปิดอยู่จริง
 */
class SurfaceFlingerSource {
    var status = "—"; private set
    private var layer: String? = null
    private var layerPkg: String? = null
    private var lastTs = 0L
    private var empty = 0
    private val ws = Regex("\\s+")

    fun reset() { layer = null; layerPkg = null; lastTs = 0; empty = 0 }

    private fun parse(text: String): List<Long> {
        val out = ArrayList<Long>(128)
        for (l in text.lineSequence().drop(1)) {
            val p = l.trim().split(ws)
            if (p.size < 3) continue
            val a = p[1].toLongOrNull() ?: continue
            if (a <= 0L || a == Long.MAX_VALUE) continue
            out.add(a)
        }
        return out
    }

    private fun findLayer(pkg: String): String? {
        val list = Shell.run("dumpsys SurfaceFlinger --list") ?: return null
        val cands = list.lines().map { it.trim() }
            .filter { it.contains(pkg) && !it.contains("Background for", true) && !it.contains("Bounds for", true) }
            .sortedByDescending { if (it.contains("SurfaceView")) 1 else 0 }
            .take(4)
        var best: String? = null
        var bestTs = 0L
        for (c in cands) {
            val newest = parse(Shell.run("dumpsys SurfaceFlinger --latency '$c'") ?: continue).maxOrNull() ?: continue
            if (newest > bestTs) { best = c; bestTs = newest }
        }
        return best
    }

    /** null = ไม่มีแหล่งข้อมูล (แสดง N/A), list = เฟรมใหม่ตั้งแต่ poll ครั้งก่อน (timestamp ns) */
    fun poll(pkg: String): List<Long>? {
        val mode = Shell.resolve()
        if (mode == Shell.Mode.NONE) {
            status = "N/A — ต้องให้สิทธิ์ DUMP ผ่าน ADB หรือใช้ Root (ดูแท็บตั้งค่า)"
            return null
        }
        if (layer == null || layerPkg != pkg) {
            layer = findLayer(pkg); layerPkg = pkg; lastTs = 0
            if (layer == null) { status = "ไม่พบเลเยอร์ภาพของ $pkg (เกมอาจยังไม่แสดงผล)"; return null }
        }
        val out = Shell.run("dumpsys SurfaceFlinger --latency '$layer'")
        if (out == null) { status = "อ่าน SurfaceFlinger ไม่สำเร็จ"; layer = null; return null }
        val ts = parse(out)
        if (ts.isEmpty()) {
            if (++empty >= 4) { layer = null; empty = 0 }
            status = "รอเฟรมจากเกม…"
            return null
        }
        empty = 0
        status = "OK · SurfaceFlinger (${if (mode == Shell.Mode.ROOT) "root" else "DUMP"})"
        if (lastTs == 0L) { lastTs = ts.maxOrNull()!!; return emptyList() }
        val fresh = ts.filter { it > lastTs }.sorted()
        if (fresh.isNotEmpty()) lastTs = fresh.last()
        return fresh
    }
}

/** หาแอปที่อยู่ด้านหน้าด้วย UsageStatsManager (ต้องเปิด Usage Access) */
class ForegroundTracker(private val ctx: Context) {
    private val usm = ctx.getSystemService(UsageStatsManager::class.java)
    private var last: String? = null
    private var lastQuery = 0L

    private val ignored: Set<String> by lazy {
        val s = hashSetOf(ctx.packageName, "com.android.systemui")
        val pm = ctx.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.queryIntentActivities(home, 0).forEach { s.add(it.activityInfo.packageName) }
        s
    }

    fun isIgnored(pkg: String) = pkg in ignored

    @Suppress("DEPRECATION")
    fun foreground(): String? {
        try {
            val now = System.currentTimeMillis()
            val begin = if (lastQuery == 0L) now - 3_600_000L else lastQuery - 1000
            val ev = usm.queryEvents(begin, now) ?: return last
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
                else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == last) last = null
            }
            lastQuery = now
        } catch (_: Exception) { }
        return last
    }

    fun label(pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    companion object {
        @Suppress("DEPRECATION")
        fun hasAccess(ctx: Context): Boolean = try {
            val ops = ctx.getSystemService(AppOpsManager::class.java)
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }
    }
}
