package com.framex.android.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.framex.android.core.*
import com.framex.android.data.Db
import com.framex.android.service.MonitorService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

fun f1(v: Float?) = v?.let { "%.1f".format(it) } ?: "N/A"
fun f0(v: Float?) = v?.let { "%.0f".format(it) } ?: "N/A"
fun pct(v: Float?) = v?.let { "${it.roundToInt()}%" } ?: "N/A"

private fun loadApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .filter { it.first != ctx.packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
}

@Composable
fun MonitorScreen() {
    val ctx = LocalContext.current
    val s by Engine.state.collectAsState()
    var target by remember { mutableStateOf(Prefs.target) }
    var overlayOn by remember { mutableStateOf(Prefs.overlayEnabled) }
    var apps by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { MonitorService.start(ctx) }
    fun start() {
        if (Prefs.overlayEnabled && !Settings.canDrawOverlays(ctx)) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else MonitorService.start(ctx)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("FRAME X", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
            modifier = Modifier.align(Alignment.Start))
        FpsGauge(s.fps, s.refreshHz)
        Text(s.appName ?: "ไม่มีเกมที่กำลังวัด", color = TextMain, fontWeight = FontWeight.Bold)
        Text(s.sourceStatus, color = if (s.sourceStatus.startsWith("OK")) Green else Amber, fontSize = 12.sp)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!s.running) Button(onClick = { start() }, Modifier.weight(1f)) {
                Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("START")
            } else Button(
                onClick = { MonitorService.stop(ctx) }, Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = TextMain)
            ) { Icon(Icons.Filled.Stop, null); Spacer(Modifier.width(6.dp)); Text("STOP") }
            Box(Modifier.weight(1f)) {
                OutlinedButton(onClick = { menu = true }, Modifier.fillMaxWidth()) {
                    Text(target?.let { t -> apps.firstOrNull { it.first == t }?.second ?: t } ?: "เป้าหมาย: อัตโนมัติ", maxLines = 1)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("อัตโนมัติ (แอปที่อยู่ด้านหน้า)") },
                        onClick = { Prefs.target = null; target = null; menu = false })
                    apps.forEach { (pkg, name) ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { Prefs.target = pkg; target = pkg; menu = false })
                    }
                }
            }
        }
        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Floating Overlay", fontWeight = FontWeight.Bold)
                    Text("แสดง FPS ทับบนเกม (ลากย้ายได้)", color = Dim, fontSize = 12.sp)
                }
                Switch(checked = overlayOn, onCheckedChange = {
                    overlayOn = it; Prefs.overlayEnabled = it
                    if (it && !Settings.canDrawOverlays(ctx))
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                    MonitorService.refresh(ctx)
                })
            }
        }

        SectionTitle("GAME FPS")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("AVG", f1(s.avgFps), Modifier.weight(1f)); Tile("MIN", f1(s.minFps), Modifier.weight(1f)); Tile("MAX", f1(s.maxFps), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("1% LOW", f1(s.low1), Modifier.weight(1f)); Tile("0.1% LOW", f1(s.low01), Modifier.weight(1f))
            Tile("FRAME TIME", s.frameMs?.let { "%.1fms".format(it) } ?: "N/A", Modifier.weight(1f))
        }
        NeonCard {
            Text("REFRESH RATE ของจอ", color = Dim, fontSize = 11.sp, letterSpacing = 1.sp)
            Text("${s.refreshHz.roundToInt()} Hz", color = Blue, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("เป็นความสามารถของหน้าจอ ไม่ใช่ FPS ที่เกมเรนเดอร์ได้", color = Dim, fontSize = 11.sp)
        }

        SectionTitle("SYSTEM")
        val sys = s.sys
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("CPU", pct(sys?.cpu), Modifier.weight(1f)); Tile("GPU", pct(sys?.gpu), Modifier.weight(1f))
            Tile("RAM", sys?.let { "%.1f/%.1fG".format(it.ramUsedMb / 1024f, it.ramTotalMb / 1024f) } ?: "N/A", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("CPU CLK", sys?.cpuFreqMhz?.let { "${it}MHz" } ?: "N/A", Modifier.weight(1f))
            Tile("GPU CLK", sys?.gpuFreqMhz?.let { "${it}MHz" } ?: "N/A", Modifier.weight(1f))
            Tile("CPU TEMP", sys?.tempCpu?.let { "%.0f°C".format(it) } ?: "N/A", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("BAT TEMP", sys?.tempBat?.let { "%.1f°C".format(it) } ?: "N/A", Modifier.weight(1f))
            Tile("BATTERY", sys?.batPct?.let { "$it%" } ?: "N/A", Modifier.weight(1f))
            Tile("DRAW", sys?.batMa?.let { "${it}mA" } ?: "N/A", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("STUTTER", "${s.stutters}", Modifier.weight(1f), if (s.stutters > 0) Amber else Cyan)
            Tile("FPS DROP", "${s.drops}", Modifier.weight(1f), if (s.drops > 0) Amber else Cyan)
            Tile("TIME", "${s.elapsedSec / 60}:%02d".format(s.elapsedSec % 60), Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun FindingsList(list: List<Finding>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { f ->
            val c = when (f.level) { Level.OK -> Green; Level.INFO -> Cyan; Level.WARN -> Amber; Level.BAD -> Red }
            NeonCard {
                Text(f.title, color = c, fontWeight = FontWeight.Bold)
                Text(f.evidence, color = TextMain, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text("แนะนำ: ${f.advice}", color = Dim, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AnalyzeScreen() {
    val s by Engine.state.collectAsState()
    val ev by Engine.events.collectAsState()
    var findings by remember { mutableStateOf<List<Finding>?>(null) }
    var title by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("FRAME TIME ANALYZER", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        NeonCard {
            Text("Frame Time (ms) — ${s.frameTimes.size} เฟรมล่าสุด", color = Dim, fontSize = 12.sp)
            val top = maxOf(40f, (s.frameTimes.maxOrNull() ?: 0f).coerceAtMost(100f))
            LineChart(s.frameTimes, minY = 0f, maxY = top, guides = listOf(8.3f, 16.7f, 33.3f), height = 150.dp)
            Text("เส้นประ = 120 / 60 / 30 FPS", color = Dim, fontSize = 11.sp)
            if (s.frameTimes.isEmpty()) Text("ยังไม่มีข้อมูลเฟรม — กด START ที่แท็บ Monitor แล้วเปิดเกม", color = Amber, fontSize = 12.sp)
        }
        NeonCard {
            Text("FPS รายวินาที", color = Dim, fontSize = 12.sp)
            LineChart(s.fpsHistory, color = Blue, minY = 0f, maxY = s.refreshHz, height = 100.dp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("STUTTER", "${s.stutters}", Modifier.weight(1f), if (s.stutters > 0) Amber else Cyan)
            Tile("FPS DROP", "${s.drops}", Modifier.weight(1f), if (s.drops > 0) Amber else Cyan)
            Tile("MAX FT", s.frameMsMax?.let { "%.0fms".format(it) } ?: "N/A", Modifier.weight(1f))
        }
        NeonCard {
            Text("ช่วงที่เกมกระตุก (บันทึกลงประวัติเมื่อจบเซสชัน)", color = Dim, fontSize = 12.sp)
            if (ev.isEmpty()) Text("ยังไม่พบ", color = Green, modifier = Modifier.padding(top = 6.dp))
            ev.takeLast(25).reversed().forEach {
                val t = it.tMs / 1000
                Text("%02d:%02d  %s  %.1f%s".format(t / 60, t % 60, if (it.type == "DROP") "FPS DROP" else "STUTTER", it.value,
                    if (it.type == "DROP") " FPS" else " ms") + if (it.note == "severe") "  ⚠" else "",
                    color = if (it.type == "DROP") Amber else Red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        Button(onClick = {
            scope.launch {
                val ses = Db.dao.latestSession()
                if (ses == null) { findings = listOf(Finding(Level.INFO, "ยังไม่มีเซสชันที่บันทึก", "เล่นเกมอย่างน้อย 5 วินาทีแล้วกด STOP", "")); title = "" }
                else { findings = Analyzer.analyze(ses, Db.dao.samples(ses.id), Db.dao.events(ses.id)); title = ses.appName }
            }
        }, Modifier.fillMaxWidth()) { Text("SMART ANALYZER — วิเคราะห์เซสชันล่าสุด") }
        findings?.let {
            if (title.isNotEmpty()) Text("ผลวิเคราะห์: $title", color = Cyan, fontWeight = FontWeight.Bold)
            FindingsList(it)
        }
    }
}
