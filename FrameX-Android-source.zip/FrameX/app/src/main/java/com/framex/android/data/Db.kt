package com.framex.android.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pkg: String, val appName: String,
    val startMs: Long, val durationMs: Long,
    val avgFps: Float?, val minFps: Float?, val maxFps: Float?,
    val low1: Float?, val low01: Float?, val avgFrameMs: Float?,
    val stutters: Int, val drops: Int,
    val refreshHz: Float, val source: String,
    val avgCpu: Float?, val avgGpu: Float?, val maxTemp: Float?,
    val batStart: Int?, val batEnd: Int?,
    val powerSave: Boolean, val ramTotalMb: Long
)

@Entity(
    tableName = "samples", indices = [Index("sessionId")],
    foreignKeys = [ForeignKey(SessionEntity::class, ["id"], ["sessionId"], onDelete = ForeignKey.CASCADE)]
)
data class SampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long, val tMs: Long,
    val fps: Float?, val avgMs: Float?, val maxMs: Float?,
    val cpu: Float?, val gpu: Float?, val ramMb: Long,
    val tempCpu: Float?, val tempBat: Float?, val batMa: Int?
)

@Entity(
    tableName = "events", indices = [Index("sessionId")],
    foreignKeys = [ForeignKey(SessionEntity::class, ["id"], ["sessionId"], onDelete = ForeignKey.CASCADE)]
)
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long, val tMs: Long,
    val type: String, val value: Float, val note: String = ""
)

@Entity(tableName = "bench")
data class BenchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timeMs: Long, val label: String,
    val cpuSingle: Float, val cpuMulti: Float,
    val cpuScore: Int, val renderScore: Int, val total: Int,
    val stages: String, val avgFps: Float, val low1: Float?,
    val refreshHz: Float, val tempStart: Float?, val tempEnd: Float?,
    val device: String
)

@Dao
interface FrameDao {
    @Insert suspend fun insertSession(s: SessionEntity): Long
    @Insert suspend fun insertSamples(l: List<SampleEntity>)
    @Insert suspend fun insertEvents(l: List<EventEntity>)
    @Insert suspend fun insertBench(b: BenchEntity): Long

    @Query("SELECT * FROM sessions ORDER BY startMs DESC") fun sessions(): Flow<List<SessionEntity>>
    @Query("SELECT * FROM sessions ORDER BY startMs DESC LIMIT 1") suspend fun latestSession(): SessionEntity?
    @Query("SELECT * FROM samples WHERE sessionId=:id ORDER BY tMs") suspend fun samples(id: Long): List<SampleEntity>
    @Query("SELECT * FROM events WHERE sessionId=:id ORDER BY tMs") suspend fun events(id: Long): List<EventEntity>
    @Query("DELETE FROM sessions WHERE id=:id") suspend fun deleteSession(id: Long)

    @Query("SELECT * FROM bench ORDER BY timeMs DESC") fun benches(): Flow<List<BenchEntity>>
    @Query("DELETE FROM bench WHERE id=:id") suspend fun deleteBench(id: Long)
}

@Database(
    entities = [SessionEntity::class, SampleEntity::class, EventEntity::class, BenchEntity::class],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() { abstract fun dao(): FrameDao }

object Db {
    private lateinit var db: AppDb
    fun init(c: Context) {
        db = Room.databaseBuilder(c.applicationContext, AppDb::class.java, "framex.db")
            .fallbackToDestructiveMigration().build()
    }
    val dao: FrameDao get() = db.dao()
}
