package com.framex.android.core

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("framex", Context.MODE_PRIVATE) }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun setB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var overlayEnabled: Boolean get() = b("ov", true); set(v) = setB("ov", v)
    var showFps: Boolean get() = b("sFps", true); set(v) = setB("sFps", v)
    var showFrame: Boolean get() = b("sFt", true); set(v) = setB("sFt", v)
    var showCpu: Boolean get() = b("sCpu", true); set(v) = setB("sCpu", v)
    var showGpu: Boolean get() = b("sGpu", true); set(v) = setB("sGpu", v)
    var showRam: Boolean get() = b("sRam", true); set(v) = setB("sRam", v)
    var showTemp: Boolean get() = b("sTemp", true); set(v) = setB("sTemp", v)
    var showGraph: Boolean get() = b("sGraph", true); set(v) = setB("sGraph", v)
    var opacity: Float get() = sp.getFloat("op", 0.9f); set(v) = sp.edit().putFloat("op", v).apply()
    var textSize: Float get() = sp.getFloat("ts", 13f); set(v) = sp.edit().putFloat("ts", v).apply()
    var posX: Int get() = sp.getInt("px", 40); set(v) = sp.edit().putInt("px", v).apply()
    var posY: Int get() = sp.getInt("py", 160); set(v) = sp.edit().putInt("py", v).apply()
    /** null = อัตโนมัติ (แอปที่อยู่ด้านหน้า) */
    var target: String?
        get() = sp.getString("target", "")?.ifBlank { null }
        set(v) = sp.edit().putString("target", v ?: "").apply()
}
